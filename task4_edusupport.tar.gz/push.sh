#!/bin/bash

TEAM_ENV_FILE="./team.env"
PORT=2222
KEY_PATH="./id_rsa"
PUB_KEY_PATH="./id_rsa.pub"

# App and logs directories
LOCAL_APP_DIR="./"
LOCAL_LOGS_DIR="./remote-logs/"


# Filters
PUSH_MODE_OPTIONS="-avh --delete --no-o --no-g --omit-dir-times --no-perms"
PUSH_GLOBAL_FILTER="--exclude=/last_push.etag --exclude=/check_start.etag --exclude=/check_end.etag --exclude=/check_result.txt --exclude=/.git --exclude=/docker-compose.yml --exclude=/.gitignore"
PUSH_APP_FILTER="--exclude=/config/sample_data --exclude=/config/mysql --exclude=/src/views --exclude=/src/static --exclude=/Dockerfile --exclude=/entrypoint.sh"

print_error_and_exit() {
  echo "Error: Critical command failed. Exiting." >&2
  echo "Please verify your team credentials and ensure that both rsync and openssh-client are installed. If the problem persists, contact the Cyberdrill team via the chat server." >&2
  exit 1
}

# Prompt for team info if not present
if [ ! -f "$TEAM_ENV_FILE" ] || [ ! -s "$TEAM_ENV_FILE" ]; then
    read -p "Enter TEAM_NAME: " TEAM_NAME
    read -p "Enter HOST: " HOST
    echo "TEAM_NAME=${TEAM_NAME}" > "$TEAM_ENV_FILE"
    echo "HOST=${HOST}" >> "$TEAM_ENV_FILE"
else
    source "$TEAM_ENV_FILE"
    echo "Using saved TEAM_NAME: $TEAM_NAME"
    echo "Using saved HOST: $HOST"
fi

# set constants based on team name
REMOTE_APP_DIR="/home/${TEAM_NAME}/app"
REMOTE_LOGS_DIR="${REMOTE_APP_DIR}/logs/"
REMOTE_ETAG_FILE="${REMOTE_APP_DIR}/last_push.etag"
REMOTE_ETAG_CHECK_START="${REMOTE_APP_DIR}/check_start.etag"
REMOTE_ETAG_CHECK_FINISHED="${REMOTE_APP_DIR}/check_end.etag"
REMOTE_CHECK_RESULT="${REMOTE_APP_DIR}/check_result.txt"

# Generate SSH key if needed
if [ ! -f "$KEY_PATH" ] || [ ! -f "$PUB_KEY_PATH" ]; then
    echo "SSH keys not found. Generating a new SSH key pair..."
    ssh-keygen -t rsa -b 2048 -f "$KEY_PATH" -q -N ""
    echo "SSH key pair generated."
fi

# Ensure SSH key is authorized using password
if ssh -i "$KEY_PATH" -p $PORT -o PasswordAuthentication=no -o BatchMode=yes "${TEAM_NAME}@${HOST}" exit 2>/dev/null; then
    echo "SSH key already authorized."
else
    echo "Authorizing SSH key with the server..."
    if ssh-copy-id -o PreferredAuthentications=password -o PubkeyAuthentication=no -i "$PUB_KEY_PATH" -p $PORT "${TEAM_NAME}@${HOST}"; then
        echo "SSH key successfully authorized."
    else
        echo "Failed to authorize SSH key. Please check your credentials." >&2
        exit 1
    fi
fi

# Push the app directory with filters
echo "Syncing app directory to the server..."
rsync $PUSH_MODE_OPTIONS -e "ssh -i $KEY_PATH -p $PORT" --filter=':- .gitignore' $PUSH_GLOBAL_FILTER $PUSH_APP_FILTER "${LOCAL_APP_DIR}" "${TEAM_NAME}@${HOST}:${REMOTE_APP_DIR}/" || print_error_and_exit

# Get mtimes
CHECK_START_MTIME=$(ssh -i $KEY_PATH -p $PORT "${TEAM_NAME}@${HOST}" "stat -c %Y ${REMOTE_ETAG_CHECK_START}")
CHECK_FINISHED_MTIME=$(ssh -i $KEY_PATH -p $PORT "${TEAM_NAME}@${HOST}" "stat -c %Y ${REMOTE_ETAG_CHECK_FINISHED}")

# Trigger check
ssh -i $KEY_PATH -p $PORT "${TEAM_NAME}@${HOST}" "touch ${REMOTE_ETAG_FILE}" || print_error_and_exit
echo -e "\e[32mApp modifications were pushed successfully! Awaiting the assessment and scoring script...\e[0m"

# Wait for check start
while true; do
    NEW_CHECK_START_MTIME=$(ssh -i $KEY_PATH -p $PORT "${TEAM_NAME}@${HOST}" "stat -c %Y ${REMOTE_ETAG_CHECK_START}")
    if [ "$NEW_CHECK_START_MTIME" -ne "$CHECK_START_MTIME" ]; then
        echo -e "\e[32mAssessment and scoring script has started!\e[0m"
        break
    else
        echo -e "\e[33mWaiting for the assessment and scoring script to start...\e[0m"
        sleep 5
    fi
done

# Wait for check end
while true; do
    NEW_CHECK_FINISHED_MTIME=$(ssh -i $KEY_PATH -p $PORT "${TEAM_NAME}@${HOST}" "stat -c %Y ${REMOTE_ETAG_CHECK_FINISHED}")
    if [ "$NEW_CHECK_FINISHED_MTIME" -ne "$CHECK_FINISHED_MTIME" ]; then
        echo -e "\e[32mAssessment and scoring script has finished!\e[0m"
        break
    else
        echo -e "\e[33mWaiting for the assessment and scoring script to finish...\e[0m"
        sleep 10
    fi
done

# Show result
echo ""
echo -e "\e[32mFeedback from the server\e[0m"
echo -e "\e[32m---------START OF FEEDBACK-----------------\e[0m"
ssh -i $KEY_PATH -p $PORT "${TEAM_NAME}@${HOST}" "cat ${REMOTE_CHECK_RESULT}"
echo ""
echo -e "\e[32m--------- END OF FEEDBACK -----------------\e[0m"
echo ""

# Pull logs
echo "Syncing remote logs back to local machine..."
rsync -avz -e "ssh -i $KEY_PATH -p $PORT" "${TEAM_NAME}@${HOST}:${REMOTE_LOGS_DIR}" "${LOCAL_LOGS_DIR}"
echo -e "\e[32mPulling logs has finished!\e[0m"
