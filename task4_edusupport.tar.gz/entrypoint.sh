#!/bin/bash
set -e

# If /var/uploads is empty, copy sample data
if [ -z "$(ls -A /var/uploads)" ]; then
  echo "Initializing /var/uploads with sample data..."
  cp -r /var/sample_data/* /var/uploads/
fi

# Fix ownership of mounted volumes
chown -R www-data:www-data /var/uploads
chown -R www-data:www-data /var/log/edusupport

# Forward to the original entrypoint
exec docker-php-entrypoint "$@"
