# Attack, Defend, Detect Challenge

Welcome to the Attack, Defend, Detect Challenge! In this task, you'll need to identify, fix, or mitigate vulnerabilities in an application and detect attempts to exploit them.

Here's everything you need to know to get started:

## 1. Setup

### 1.1 Installing Docker and Docker Compose

### On Windows with WSL2

Follow the instructions [here](https://docs.microsoft.com/en-us/windows/wsl/install) to install WSL2 and an ubuntu VM.

### On Debian/Ubuntu

```bash
sudo apt update
sudo apt install -y docker.io docker-compose
```

### Other Linux Distributions

Follow the instructions [here](https://docs.docker.com/compose/install/) to install docker and docker-compose.

### Other requirements

You will need rsync and openssh-client to push changes to the remote server and to pull logs. To install on Debian/Ubuntu:

```bash
sudo apt update
sudo apt install -y docker.io docker-compose
```

### 1.2 Starting the Project

1. **Navigate to the Project Directory:**

    ```bash
    cd /path/to/your/project
    ```

2. **Start the Project with Docker Compose:**

    ```bash
    docker-compose up
    ```

3. **Access the Services:**
    - Open your web browser and navigate to [http://localhost:8901](http://localhost:8901/) to access the main service.
    - To access phpMyAdmin, go to [http://localhost:8902](http://localhost:8902/).

---

## 2. Challenges

### 2.1 Attack Challenge

- **Objective:** Find the flags using the identified vulnerabilities in the attack instance.
- **Important:** Always test locally before attempting to exploit vulnerabilities.

### 2.2 Defend Challenge

- **Objective:** After identifying vulnerabilities, apply necessary fixes to your instance of the project. Push these changes to the SFTP server provided using `push-changes.sh`. Your updated configuration will be tested for functionality and vulnerabilities, and a new traffic will be generated for the Detect Challenge.
- **Important:** Always test your changes locally before pushing them to the server.
- **Restrictions:** You **cannot** update the frontend, databases, sample data, configurations and startup scripts.

### 2.3 Detect Challenge

- **Objective:** Find vulnerabilities exploitation attempts. You can use either the sample logs that are stored in `./sample-logs`, or, download new logs after pushing changes.
- **Important:** There are three log directories: `sample-logs` (included with the project tar.gz), `logs` (your local logs), and `remote-logs` (logs fetched from your assessment instance after pushing changes).

    Wait a few minutes after submitting your changes for the traffic to be generated before downloading new logs.


### 2.4 Challenge Approaches

1. **The Red-Team Way:** Pentest the app locally to discover vulnerabilities.
2. **The Threat-Hunter Way:** Analyze the logs to detect exploitation attempts. You can modify the configuration to capture additional logs or fields.
3. **The DevSecOps Way:** Analyze the code to identify vulnerabilities.

A hybrid approach combining these methods is likely to yield the best results.

---

## 3. Application Overview

### 3.1 EduSupport System

**EduSupport** is a platform developed by the Ministry of National Education to manage grants and student support services.

**Key Actors:**

- **Students:** Submit applications along with supporting documents (e.g., proof of income, civil status, etc.).
- **Educational Institution Representatives:** Submit academic records on behalf of students.
- **EduSupport Regional Agents:** Review and validate submitted applications.

### 3.2 Flag Locations

- **Flag1:** inside one of the uploaded PDFs ex: `./config/sample_data/uploads/63.pdf`
- **Flag2:** in `./src/.env`
- **Flag3:** in table `edusupport.users`, id:13370, username:admin
- **Flag4:** in table `grades.grades`, id>1000
- **Flag5:** in table `edusupport.applications`, id:13370, student_id:2008TT999999

### **3.3. Extra Notes:**

- The [push.sh](http://push.sh/) script will prompt you to enter the remote host’s IP address, username, and password. Refer to the exercise description for these details.
- You can use PhpMyAdmin http://127.0.0.1:8902 to view and explore your databases.
- Sample **account credentials** for accessing and auditing the different roles and views of your local instance are stored in JSON files located in the **./config/sample_data/json/{role}s.json** directory.
- Sample data, IDs, and secrets **may differ between** your instance and the attack and assessment instances.
- **Technology Stack:** [Nginx](https://nginx.org/en/docs/), [PHP](https://www.php.net/docs.php), [MySQL](https://dev.mysql.com/doc/), [Docker](https://docs.docker.com/), Feel free to use AI tools to assist with code updates, but always test changes locally before pushing.

Good luck, and have fun with the challenge!