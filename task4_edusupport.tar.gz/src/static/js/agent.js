function agentDashboard() {
    return {
        applications: [],
        statusUpdate: {},
        messages: {},
        grades: [],
        gradesStudentId: '',
        showGradesModal: false,
        showGradesTable: false,

        init() {
            const token = localStorage.getItem('token');
            if (!token) window.location.href = '/logout.php';
            this.fetchApplications();
        },

        fetchApplications() {
            fetch('/api/agent/applications.php', {
                headers: {'Authorization': 'Bearer ' + localStorage.getItem('token')}
            })
                .then(res => res.json())
                .then(data => {
                    this.applications = data;
                    // Initialize statusUpdate and messages per application
                    this.applications.forEach(app => {
                        this.statusUpdate[app.application_id] = '';
                        this.messages[app.application_id] = '';
                    });
                });
        },

        statusClass(status) {
            switch (status.toLowerCase()) {
                case 'approved':
                    return 'badge bg-success';
                case 'rejected':
                    return 'badge bg-danger';
                case 'requiring additional documents':
                    return 'badge bg-warning text-dark';
                default:
                    return 'badge bg-secondary';
            }
        },

        loadGrades(student_id) {
            fetch(`/api/institution/grades.php?student_id=${student_id}`, {
                headers: {'Authorization': 'Bearer ' + localStorage.getItem('token')}
            })
                .then(res => res.json())
                .then(data => {
                    this.grades = data;
                    this.gradesStudentId = student_id;
                    this.showGradesModal = true;
                    this.showGradesTable = data && data.length > 0;
                });
        },

        changeStatus(application_id) {
            // no auto action, waits for submitStatus click
        },

        calculateMoyenne() {
            const gradeMap = this.grades.reduce((acc, g) => {
                acc[g.subject] = g.grade;
                return acc;
            }, {});

            let cc = parseFloat(gradeMap['controle continu']) || 0;
            let regional = parseFloat(gradeMap.regional) || 0;
            let national = parseFloat(gradeMap.national) || 0;
            return ((regional * 0.25) + (cc * 0.25) + (national * 0.5)).toFixed(2);
        },

        submitStatus(application_id) {
            const status = this.statusUpdate[application_id];
            const message = this.messages[application_id];

            if (!status) {
                alert('Please select a status.');
                return;
            }

            fetch('/api/agent/applications.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + localStorage.getItem('token')
                },
                body: JSON.stringify({application_id, status, message})
            }).then(res => {
                if (res.ok) {
                    alert('Status updated!');
                    this.fetchApplications();
                    this.statusUpdate[application_id] = '';
                    this.messages[application_id] = '';
                } else {
                    alert('Failed to update status.');
                }
            });
        },


        logout() {
            localStorage.removeItem('token');
            window.location.href = '/logout.php';
        }
    }
}