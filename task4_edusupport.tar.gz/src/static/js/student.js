function studentDashboard() {
  return {
    token: localStorage.getItem('token'),
    status: 'loading',
    application: null,
    agentMessage: '',
    documents: [],
    formVisible: true,
    form: {
      fullname: '',
      income: '',
      institution: '',
      city: '',
      region: ''
    },

    get statusText() {
      return this.status.replace(/_/g, ' ');
    },
    get statusClass() {
      const map = {
        not_submitted: 'bg-secondary',
        submitted: 'bg-info',
        requiring_documents: 'bg-warning',
        approved: 'bg-success',
        rejected: 'bg-danger'
      };
      return 'badge ' + (map[this.status] || 'bg-secondary');
    },

    init() {
      if (!this.token) {
        window.location.href = '/logout.php';
        return;
      }
      this.fetchApplication();
      this.fetchDocuments();
    },

    logout() {
      localStorage.removeItem('token');
      window.location.href = '/logout.php';
    },

    fetchApplication() {
      fetch('/api/student/application.php', {
        headers: { 'Authorization': 'Bearer ' + this.token }
      })
        .then(res => res.json())
        .then(data => {
          if (data.success && data.application) {
            this.application = data.application;
            this.status = data.application.status;
            this.agentMessage = data.application.agent_message || '';
            this.formVisible = false; // Hide form by default
          } else {
            this.application = null;
            this.status = 'not_submitted';
            this.agentMessage = '';
            this.formVisible = true; // Show form for first-time submission
          }
        })
        .catch(err => {
          console.error(err);
          this.status = 'not_submitted';
          this.formVisible = true;
        });
    },

    fetchDocuments() {
      fetch('/api/student/application.php', {
        headers: { 'Authorization': 'Bearer ' + this.token }
      })
        .then(res => res.json())
        .then(data => {
          this.documents = data.application?.documents || [];
        })
        .catch(err => {
          console.error(err);
          this.documents = [];
        });
    },

    submitApplication() {
      const payload = {
        fullname: this.form.fullname,
        parent_income: parseInt(this.form.income, 10),
        institution: this.form.institution,
        city: this.form.city,
      };

      fetch('/api/student/application.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + this.token
        },
        body: JSON.stringify(payload)
      })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            alert("Application submitted successfully.");
            this.fetchApplication();
          } else {
            alert("Error: " + (data.error || "Unknown error."));
          }
        })
        .catch(err => {
          console.error("Submission failed", err);
          alert("Network error.");
        });
    },

    uploadDocument() {
      const fileInput = this.$refs.documentFile;
      if (!fileInput.files.length) return alert("Please select a file.");

      const formData = new FormData();
      formData.append("document", fileInput.files[0]);

      fetch('/api/student/document.php', {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer ' + this.token
        },
        body: formData
      })
        .then(res => res.json())
        .then(data => {
          if (data.status === 'success') {
            alert('Document uploaded successfully.');
            fileInput.value = '';
            this.fetchDocuments();
          } else {
            alert('Failed to upload document.');
          }
        })
        .catch(err => {
          console.error('Upload error:', err);
          alert('An error occurred while uploading the document.');
        });
    },

    editApplication() {
      if (!this.application) return;
      this.form.fullname = this.application.fullname;
      this.form.income = this.application.parent_income;
      this.form.institution = this.application.institution;
      this.form.city = this.application.city;
      this.formVisible = true;
    }
  };
}