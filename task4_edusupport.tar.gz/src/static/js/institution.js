function institutionDashboard() {
    return {
        students: [],
        selectedStudent: null,
        grades: { cc: '', regional: '', national: '' },

        init() {
            const token = localStorage.getItem('token');
            if (!token) window.location.href = '/logout.php';
            this.fetchStudents();
        },

        async fetchStudents() {
            const token = localStorage.getItem('token');
            const res = await fetch('/api/institution/students.php', {
                headers: { 'Authorization': 'Bearer ' + token }
            });
            const data = await res.json();
            this.students = await Promise.all(
                data.map(async student => {
                    const gradesRes = await fetch(`/api/institution/grades.php?student_id=${student.student_id}`, {
                        headers: { 'Authorization': 'Bearer ' + token }
                    });
                    const gradesData = await gradesRes.json();

                    const cc = gradesData.find(g => g.subject === 'controle continu')?.grade ?? null;
                    const regional = gradesData.find(g => g.subject === 'regional')?.grade ?? null;
                    const national = gradesData.find(g => g.subject === 'national')?.grade ?? null;
                    const submitted = cc !== null && regional !== null && national !== null;

                    return {
                        ...student,
                        grades_submitted: submitted,
                        grades_preview: {
                            cc: cc ?? '--',
                            regional: regional ?? '--',
                            national: national ?? '--',
                            moyenne: submitted
                                ? ((regional * 0.25 + cc * 0.25 + national * 0.5).toFixed(2))
                                : '--'
                        }
                    };
                })
            );
        },

        selectStudent(student) {
            this.selectedStudent = student;
            this.grades = { cc: '', regional: '', national: '' };

            fetch(`/api/institution/grades.php?student_id=${student.student_id}`, {
                headers: { 'Authorization': 'Bearer ' + localStorage.getItem('token') }
            })
                .then(res => res.json())
                .then(data => {
                    data.forEach(g => {
                        if (g.subject === 'controle continu') this.grades.cc = g.grade;
                        if (g.subject === 'regional') this.grades.regional = g.grade;
                        if (g.subject === 'national') this.grades.national = g.grade;
                    });
                });
        },

        calculateMoyenne() {
            const cc = parseFloat(this.grades.cc) || 0;
            const regional = parseFloat(this.grades.regional) || 0;
            const national = parseFloat(this.grades.national) || 0;
            return ((regional * 0.25) + (cc * 0.25) + (national * 0.5)).toFixed(2);
        },

        submitGrades() {
            const body = {
                student_id: this.selectedStudent.student_id,
                grades: [
                    { subject: 'controle continu', grade: this.grades.cc },
                    { subject: 'regional', grade: this.grades.regional },
                    { subject: 'national', grade: this.grades.national }
                ]
            };

            fetch('/api/institution/grades.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + localStorage.getItem('token')
                },
                body: JSON.stringify(body)
            }).then(res => {
                if (res.ok) {
                    alert('Grades submitted!');
                    this.selectedStudent = null;
                    this.fetchStudents(); // refresh to show updated preview
                }
            });
        },

        logout() {
            localStorage.removeItem('token');
            window.location.href = '/logout.php';
        }
    };
}
