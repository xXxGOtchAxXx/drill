<?php
require_once __DIR__ . '/../lib/auth.php';
$user = get_user();
if (!$user || $user['role'] !== 'institution') {
    header("Location: /logout.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>EduSupport - Institution Dashboard</title>
  <link href="/static/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/static/plugins/font-awesome/css/all.min.css" rel="stylesheet">
  <script src="/static/plugins/alpinejs/cdn.min.js" defer></script>
</head>
<!-- ... (Previous PHP and head code remains unchanged) -->
<body class="bg-light" x-data="institutionDashboard()" x-init="init()">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <span class="navbar-brand d-flex align-items-center">
      <img src="/static/logo_mono.png" alt="Logo" height="30" class="me-2" style="filter: brightness(0) invert(1);">
      EduSupport - Institution
    </span>
    <div class="d-flex">
      <button class="btn btn-outline-light" @click="logout()">
        <i class="fas fa-sign-out-alt"></i> Logout
      </button>
    </div>
  </div>
</nav>

  <div class="container mt-4">
    <h3 class="mb-3">Students with Applications</h3>
    <div class="table-responsive">
      <table class="table table-bordered table-striped align-middle">
        <thead class="table-light">
          <tr>
            <th>Student ID</th>
            <th>Full Name</th>
            <th>Grades Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <template x-for="student in students" :key="student.student_id">
            <tr>
              <td x-text="student.student_id"></td>
              <td x-text="student.fullname"></td>
              <td>
                <span x-text="student.grades_submitted ? 'Submitted' : 'Not Submitted'"
                      :class="student.grades_submitted ? 'text-success' : 'text-danger'"></span>
                                <template x-if="student.grades_submitted">
                  <div>
                    <small>CC: <span x-text="student.grades_preview.cc"></span></small><br>
                    <small>Regional: <span x-text="student.grades_preview.regional"></span></small><br>
                    <small>National: <span x-text="student.grades_preview.national"></span></small><br>
                    <small>Moyenne: <span x-text="student.grades_preview.moyenne"></span></small>
                  </div>
                </template>
              </td>
              <td>
                <button class="btn btn-sm btn-outline-primary" @click="selectStudent(student)">
                  <i class="fas fa-edit"></i> Edit Grades
                </button>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>

    <div class="mt-5" x-show="selectedStudent" x-cloak>
      <h4>Edit Grades for <span x-text="selectedStudent?.fullname"></span> (<span x-text="selectedStudent?.student_id"></span>)</h4>
      <form @submit.prevent="submitGrades" class="mt-3">
        <div class="row">
          <div class="col-md-3 mb-3">
            <label class="form-label">Contrôle Continu</label>
            <input type="number" step="0.01" class="form-control" x-model="grades.cc" min="0" max="20" required>
          </div>
          <div class="col-md-3 mb-3">
            <label class="form-label">Régional</label>
            <input type="number" step="0.01" class="form-control" x-model="grades.regional" min="0" max="20" required>
          </div>
          <div class="col-md-3 mb-3">
            <label class="form-label">National</label>
            <input type="number" step="0.01" class="form-control" x-model="grades.national" min="0" max="20" required>
          </div>
          <div class="col-md-3 mb-3">
            <label class="form-label">Moyenne</label>
            <input type="text" class="form-control bg-light" :value="calculateMoyenne()" readonly>
          </div>
        </div>
        <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save Grades</button>
      </form>
    </div>
  </div>

  <script src="/static/js/institution.js"></script>
</body>

</html>
