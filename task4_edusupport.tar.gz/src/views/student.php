<?php
require_once __DIR__ . '/../lib/auth.php';
$user = get_user();
if (!$user || $user['role'] !== 'student') {
    header("Location: /logout.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" x-data="studentDashboard()" x-init="init">
<head>
  <meta charset="UTF-8">
  <title>EduSupport - Student Dashboard</title>
  <link href="/static/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/static/plugins/font-awesome/css/all.min.css" rel="stylesheet">
  <script defer src="/static/plugins/alpinejs/cdn.min.js"></script>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <span class="navbar-brand d-flex align-items-center">
      <img src="/static/logo_mono.png" alt="Logo" height="30" class="me-2" style="filter: brightness(0) invert(1);">
      EduSupport - Student
    </span>
    <div class="d-flex">
      <button class="btn btn-outline-light" @click="logout()">
        <i class="fas fa-sign-out-alt"></i> Logout
      </button>
    </div>
  </div>
</nav>

  <div class="container mt-4">
    <h3 class="mb-3">Application Status</h3>
    <div class="mb-4">
      <p>Status:
        <span class="badge" :class="statusClass" x-text="statusText">Loading...</span>
      </p>
      <div class="alert alert-info" x-show="agentMessage" x-text="agentMessage"></div>

      <!-- Show submitted info -->
      <div class="border p-3" x-show="!formVisible && application">
        <h5>Submitted Info</h5>
        <p><strong>Full Name:</strong> <span x-text="application?.fullname"></span></p>
        <p><strong>Parent Income:</strong> <span x-text="application?.parent_income"></span> DH</p>
        <p><strong>Institution:</strong> <span x-text="application?.institution"></span></p>
        <p><strong>City:</strong> <span x-text="application?.city"></span></p>
        <p><strong>Region:</strong> <span x-text="application?.region"></span></p>
        <template x-if="status === 'submitted' || status === 'requiring_documents'">
          <button class="btn btn-sm btn-outline-primary mt-2" @click="editApplication"><i class="fas fa-edit"></i> Edit</button>
        </template>
      </div>
    </div>

    <!-- Application Form -->
    <div x-show="formVisible">
      <h3 x-text="application ? 'Update Application' : 'Submit Application'"></h3>
      <form @submit.prevent="submitApplication" class="mb-5">
        <div class="mb-3">
          <label class="form-label">Full Name</label>
          <input type="text" class="form-control" x-model="form.fullname" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Parent Income</label>
          <input type="number" class="form-control" x-model="form.income" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Institution</label>
          <input type="text" class="form-control" x-model="form.institution" required>
        </div>
        <div class="mb-3">
          <label class="form-label">City</label>
          <input type="text" class="form-control" x-model="form.city" required>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit</button>
      </form>
    </div>

    <h3>Uploaded Documents</h3>
    <div class="mb-3">
      <template x-if="documents.length === 0">
        <p>No documents uploaded yet.</p>
      </template>
      <ul class="list-group" x-show="documents.length > 0">
        <template x-for="doc in documents" :key="doc.id">
          <li class="list-group-item d-flex justify-content-between align-items-center">
            <i :class="doc.type === 'pdf' ? 'fas fa-file-pdf text-danger' : 'fas fa-file-image text-primary'" class="me-2"></i>
            <a :href="`/api/student/document.php?doc_id=${encodeURIComponent(doc.id)}`" target="_blank" x-text="doc.filename"></a>
          </li>
        </template>
      </ul>
    </div>

    <form @submit.prevent="uploadDocument" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Upload Document (PDF or JPG)</label>
        <input type="file" class="form-control" x-ref="documentFile" accept=".pdf,.jpg,.jpeg" required>
      </div>
      <button type="submit" class="btn btn-success"><i class="fas fa-upload"></i> Upload</button>
    </form>
  </div>
<script src="/static/js/student.js"></script>

</body>
</html>
