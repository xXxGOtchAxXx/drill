<?php
require_once __DIR__ . '/../lib/auth.php';
$user = get_user();
if (!$user || $user['role'] !== 'agent') {
    header("Location: /logout.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" x-data="agentDashboard()" x-init="init()" >
<head>
  <meta charset="UTF-8" />
  <title>EduSupport - Agent Dashboard</title>
  <link href="/static/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
  <link href="/static/plugins/font-awesome/css/all.min.css" rel="stylesheet" />
  <script src="/static/plugins/alpinejs/cdn.min.js" defer></script>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <div class="container-fluid">
        <span class="navbar-brand d-flex align-items-center">
          <img src="/static/logo_mono.png" alt="Logo" height="30" class="me-2" style="filter: brightness(0) invert(1);">
          EduSupport - Agent
        </span>
        <div class="d-flex">
          <button class="btn btn-outline-light" @click="logout()">
            <i class="fas fa-sign-out-alt"></i> Logout
          </button>
        </div>
      </div>
    </nav>



  <div class="container mt-4">
    <h3 class="mb-3">Applications in Your Region</h3>
    <div class="table-responsive">
      <table class="table table-bordered table-striped align-middle">
        <thead class="table-light">
          <tr>
            <th>Student ID</th>
            <th>Full Name</th>
            <th>Parent Income</th>
            <th>Status</th>
            <th>Documents</th>
            <th>Grades</th>
            <th>Change Status</th>
          </tr>
        </thead>
        <tbody>
          <template x-for="app in applications" :key="app.application_id">
            <tr>
              <td x-text="app.student_id"></td>
              <td x-text="app.fullname"></td>
              <td><span x-text="app.parent_income"></span> DH</td>
              <td>
                <span :class="statusClass(app.status)" x-text="app.status"></span>
                <p x-show="app.agent_message" class="mt-3" ><span x-text="app.agent_message || '' "></span></p>
              </td>
              <td>
                <template x-for="doc in app.documents" :key="doc.doc_id">
                  <a :href="`/api/student/document.php?doc_id=${doc.doc_id}`" target="_blank" class="btn btn-sm btn-outline-info me-1" title="View Document">
                    <i class="fas fa-file-pdf"></i>
                  </a>
                </template>
              </td>
              <td>
                <button class="btn btn-sm btn-outline-primary" @click="loadGrades(app.student_id)">
                  <i class="fas fa-graduation-cap"></i> View Grades
                </button>
              </td>
              <td>
                <select class="form-select form-select-sm mb-1" x-model="statusUpdate[app.application_id]" @change="changeStatus(app.application_id)">
                  <option value="" selected disabled>Change status</option>
                  <option value="requiring additional documents">Requiring additional documents</option>
                  <option value="approved">Approved</option>
                  <option value="rejected">Rejected</option>
                </select>
                <textarea class="form-control form-control-sm" rows="2" placeholder="Message" x-model="messages[app.application_id]"></textarea>
                <button class="btn btn-sm btn-success mt-1" @click="submitStatus(app.application_id)">
                  <i class="fas fa-paper-plane"></i> Submit
                </button>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
<!-- Static Bootstrap 5 Modal Always Visible -->
<div class="modal"  tabindex="-1" role="dialog" style="background-color: rgba(0,0,0,0.5);"  >
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Grades for Student XYZ</h5>
      </div>
      <div class="modal-body">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Type</th>
              <th>Grade</th>
            </tr>
          </thead>
          <tbody>
            <tr><td>Regional</td><td>15</td></tr>
            <tr><td>National</td><td>18</td></tr>
            <tr><td>Controle Continu</td><td>14</td></tr>
            <tr><td>Moyenne</td><td>16.25</td></tr>
          </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" disabled>Close (disabled)</button>
      </div>
    </div>
  </div>
</div>

    <!-- Grades Modal -->
    <div
      class="modal"
      :class="showGradesModal?'d-block':'fade'"

      tabindex="-1"
      role="dialog"
      @click.outside="showGradesModal = false"
      x-transition
    >

      <div class="modal-dialog modal-lg" role="document" @click.stop>
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Grades for <span x-text="gradesStudentId"></span></h5>
            <button type="button" class="btn-close" @click="showGradesModal = false"></button>
          </div>
          <div class="modal-body">
            <table class="table table-bordered" x-show="showGradesTable">
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Grade</th>
                </tr>
              </thead>
              <tbody>
                <template x-for="g in grades" :key="g.subject">
                  <tr>
                    <td x-text="g.subject"></td>
                    <td x-text="g.grade"></td>
                  </tr>
                </template>
                <tr>
                  <td><strong>Moyenne</strong></td>
                  <td><strong x-text="calculateMoyenne()"></strong></td>
                </tr>
              </tbody>
            </table>
            <div class="alert alert-warning p-1 m-0" x-show="!showGradesTable" role="alert">Grades are not submitted yet</div>


          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" @click="showGradesModal = false">Close</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="/static/js/agent.js"></script>

</body>
</html>
