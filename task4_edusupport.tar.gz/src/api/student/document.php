<?php
// /api/student/document.php
require_once '../../lib/auth.php';
require_once '../../lib/mysql.php';

header('Content-Type: application/json');



$db = get_connection('edusupport');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    if (empty($_GET['doc_id']) || !ctype_digit($_GET['doc_id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid or missing doc_id']);
        exit;
    }

    $doc_id = intval($_GET['doc_id']);

    $stmt = $db->prepare("SELECT id, filename, type FROM documents WHERE id = ?");
    $stmt->bind_param("i", $doc_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['error' => 'Document not found']);
        exit;
    }

    $doc = $result->fetch_assoc();
    $file_path = '/var/uploads/' . $doc['id'];

    if (!file_exists($file_path)) {
        http_response_code(404);
        echo json_encode(['error' => 'File missing']);
        exit;
    }

    // Serve file with correct headers
    $mime = $doc['type'] === 'pdf' ? 'application/pdf' : 'image/jpeg';
    header('Content-Type: ' . $mime);
    header('Content-Disposition: inline; filename="' . basename($doc['filename']) . '"');
    readfile($file_path);
    exit;

} elseif ($method === 'POST') {
    $user = get_token_user();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }

    // POST /api/student/document.php - upload document (pdf or jpg)

    if (!isset($_FILES['document'])) {
        http_response_code(400);
        echo json_encode(['error' => 'No document uploaded']);
        exit;
    }

    $file = $_FILES['document'];
    $allowed_types = ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['error' => 'Upload error']);
        exit;
    }

    if (!array_key_exists($file['type'], $allowed_types)) {
        http_response_code(400);
        echo json_encode(['error' => 'Unsupported file type']);
        exit;
    }
    $ext = $allowed_types[$file['type']];
    //$filename = uniqid('doc_', true) . '.' . $ext;

    // Insert document record
    $stmt = $db->prepare("INSERT INTO documents (student_id, filename, type) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $user['username'], $_FILES['document']['name'], $ext);
    if ($stmt->execute()) {

    } else {
        // Rollback file on DB failure
        // unlink($target_path);
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
    }


    $target_path = '/var/uploads/' . $stmt->insert_id;

    if (!move_uploaded_file($file['tmp_name'], $target_path)) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save file']);
        exit;
    }

    echo json_encode(['status' => 'success', 'doc_id' => $stmt->insert_id]);

    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
