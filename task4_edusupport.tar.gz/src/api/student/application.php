<?php
// /api/student/application.php

require_once '../../lib/auth.php';
require_once '../../lib/mysql.php';
require_once '../../lib/logging.php';

header('Content-Type: application/json');

$user = get_token_user();
if (!$user || $user['role'] !== 'student') {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

// Connect to edusupport DB
$conn = get_connection('edusupport');
if (!$conn) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

$student_id = $user['username'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch application + documents for this student_id
    $stmt = $conn->prepare("SELECT id, fullname, parent_income, institution, city, region, status, agent_message FROM applications WHERE student_id = ?");
    $stmt->bind_param('s', $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $application = $result->fetch_assoc();

    // If no application found, return success false but no error (empty)
    if (!$application) {
        echo json_encode(['success' => true, 'application' => null]);
        exit;
    }

    // Fetch documents for this student
    $docStmt = $conn->prepare("SELECT id, filename, type FROM documents WHERE student_id = ?");
    $docStmt->bind_param('s', $student_id);
    $docStmt->execute();
    $docsResult = $docStmt->get_result();
    $documents = [];
    while ($row = $docsResult->fetch_assoc()) {
        $documents[] = $row;
    }
    $application['documents'] = $documents;

    echo json_encode(['success' => true, 'application' => $application]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Read input JSON
    $input = json_decode(file_get_contents('php://input'), true);

    // debug("post student/application.php: ". json_encode($input, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));

    if (!$input) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid JSON']);
        exit;
    }

    $fullname = trim($input['fullname'] ?? '');
    $parent_income = intval($input['parent_income'] ?? -1);
    $institution = trim($input['institution'] ?? '');
    $city = trim($input['city'] ?? '');
    $region = $user['region'];

    if ($fullname === '' || $parent_income < 0 || $institution === '' || $city === '' || $region === '') {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing or invalid fields']);
        exit;
    }

    // Check if application exists
    $checkStmt = $conn->prepare("SELECT id FROM applications WHERE student_id = ?");
    $checkStmt->bind_param('s', $student_id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    $exists = $checkResult->fetch_assoc();

    if ($exists) {
        // Update existing application, keep status same or reset to submitted if was not submitted
        $updateStmt = $conn->prepare(
            "UPDATE applications SET fullname=?, parent_income=?, institution=?, city=?, region=?, status='submitted', agent_message=NULL WHERE student_id=?"
        );
        $updateStmt->bind_param('sissss', $fullname, $parent_income, $institution, $city, $region, $student_id);
        $ok = $updateStmt->execute();
    } else {
        // Insert new application with status not_submitted or submitted? Use submitted.
        $insertStmt = $conn->prepare(
            "INSERT INTO applications (student_id, fullname, parent_income, institution, city, region, status) VALUES (?, ?, ?, ?, ?, ?, 'submitted')"
        );
        $insertStmt->bind_param('ssisss', $student_id, $fullname, $parent_income, $institution, $city, $region);
        $ok = $insertStmt->execute();
    }

    if (!$ok) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to save application']);
        exit;
    }

    echo json_encode(['success' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'error' => 'Method not allowed']);
exit;
