<?php
// /api/agent/applications.php

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/mysql.php';

header('Content-Type: application/json');

$user = get_token_user();
if (!$user || $user['role'] !== 'agent') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$mysqli = get_connection('edusupport');
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // List applications for agent region
    $region = $user['region']; // agent's region

    $stmt = $mysqli->prepare("
        SELECT *
        FROM applications
        WHERE region = ?
    ");
    $stmt->bind_param('s', $region);
    $stmt->execute();
    $result = $stmt->get_result();

    $applications = [];
    while ($row = $result->fetch_assoc()) {
        // Get documents for the application
        $docs_stmt = $mysqli->prepare("SELECT id FROM documents WHERE student_id = ?");
        $docs_stmt->bind_param('s', $row['student_id']);
        $docs_stmt->execute();
        $docs_res = $docs_stmt->get_result();
        $documents = [];
        while ($doc = $docs_res->fetch_assoc()) {
            $documents[] = ['doc_id' => $doc['id']];
        }
        $docs_stmt->close();

        $applications[] = [
            'application_id' => $row['student_id'],
            'parent_income' => $row['parent_income'],
            'student_id' => $row['student_id'],
            'fullname' => $row['fullname'],
            'status' => $row['status'],
            'agent_message' => $row['agent_message'],
            'documents' => $documents
        ];
    }
    $stmt->close();

    echo json_encode($applications);

} elseif ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['application_id'], $input['status'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing parameters']);
        exit;
    }

    $application_id = $input['application_id'];
    $status = $input['status'];
    $message = $input['message'] ?? '';

    // Validate status values
    $valid_statuses = ['requiring additional documents', 'approved', 'rejected'];
    if (!in_array(strtolower($status), $valid_statuses)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid status']);
        exit;
    }

    // Check application belongs to agent's region
    $check_stmt = $mysqli->prepare("SELECT region FROM applications WHERE student_id = ?");
    $check_stmt->bind_param('s', $application_id);
    $check_stmt->execute();
    $check_stmt->bind_result($app_region);
    if (!$check_stmt->fetch()) {
        http_response_code(404);
        echo json_encode(['error' => 'Application not found']);
        exit;
    }
    $check_stmt->close();

    if ($app_region !== $user['region']) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        exit;
    }
    // Update application status and agent message
    $update_stmt = $mysqli->prepare("UPDATE applications SET status = ?, agent_message = ? WHERE student_id = ?");
    $update_stmt->bind_param('sss', $status, $message, $application_id);
    $success = $update_stmt->execute();
    $count = $update_stmt->affected_rows;
    $update_stmt->close();

    if ($success && $count) {
        echo json_encode(['status' => 'success',]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update application']);
    }

} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
