<?php
require_once __DIR__ . '/../lib/auth.php';

header('Content-Type: application/json');

logout();
echo json_encode([
    'success' => true,
    'redirect' => '/',
]);
