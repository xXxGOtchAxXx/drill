<?php
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/logging.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

header('X-Username: '.$username);
$user = validate_login($username, $password);

if (!$user) {
    audit_log("login", false, "login failed", $username);
    error("Failed authentication attempt for user=".$username);
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
    exit;
}

audit_log("login", true, null, $username);

$redirect = match ($user['role']) {
    'student' => '/views/student.php',
    'agent' => '/views/agent.php',
    'institution' => '/views/institution.php',
    default => '/',
};

echo json_encode([
    'success' => true,
    'token' => generate_token($user),
    'user' => $user,
    'redirect' => $redirect
]);
