<?php
require_once __DIR__ . '/../lib/auth.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$username = $_POST['username'] ?? '';

$user = user_info($username, );

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid account']);
    exit;
}


echo json_encode([
    'success' => true,
    'user' => $user,
]);
