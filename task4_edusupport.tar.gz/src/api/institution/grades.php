<?php
// /api/institution/grades.php

require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/mysql.php';

header('Content-Type: application/json');

$user = get_token_user();
if (!$user || ($user['role'] !== 'institution' && $user['role'] !== 'agent')) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$mysqli = get_connection('grades');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $student_id = $_GET['student_id'] ?? '';

    // clean $student_id; remove special characters
    $student_id = preg_replace('/["%;#\\-]/', '', $student_id);


    $query = "SELECT subject, grade FROM grades WHERE student_id = '$student_id';";
    $result = $mysqli->query($query);

    if (!$result) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
        exit;
    }

    $grades = [];
    $allowed_subjects = ['regional', 'controle continu', 'national'];

    while ($row = $result->fetch_assoc()) {
        $subject = strtolower($row['subject']);
        if (in_array($subject, $allowed_subjects)) {
            $grades[] = ['subject' => $subject, 'grade' => floatval($row['grade'])];
        }
    }
    echo json_encode($grades);

} elseif ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['student_id'], $input['grades']) || !is_array($input['grades'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid input']);
        exit;
    }

    $student_id = $input['student_id'];

    // Check institution access to student is out of scope here (assumed validated elsewhere)

    // Start transaction
    $mysqli->begin_transaction();

    // Delete existing grades for student
    $stmt_del = $mysqli->prepare("DELETE FROM grades WHERE student_id = ?");
    $stmt_del->bind_param('s', $student_id);
    $stmt_del->execute();
    $stmt_del->close();

    // Insert new grades
    $stmt_ins = $mysqli->prepare("INSERT INTO grades (student_id, subject, grade) VALUES (?, ?, ?)");

    foreach ($input['grades'] as $grade) {
        $subject = strtolower(trim($grade['subject']));
        $grade_val = floatval($grade['grade']);

        if (!in_array($subject, ['controle continu', 'regional', 'national'])) {
            // ignore unknown subjects
            continue;
        }
        if ($grade_val < 0 || $grade_val > 20) {
            continue;
        }

        $stmt_ins->bind_param('ssd', $student_id, $subject, $grade_val);
        $stmt_ins->execute();
    }
    $stmt_ins->close();

    $mysqli->commit();

    echo json_encode(['status' => 'success']);
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
