<?php
require_once __DIR__ . '/../../lib/auth.php';
require_once __DIR__ . '/../../lib/mysql.php';

header('Content-Type: application/json');

$user = get_token_user();
if (!$user || $user['role'] !== 'institution') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$conn = get_connection('edusupport');

$institution = $conn->real_escape_string($user['username']);

$query = "
    SELECT student_id, fullname, institution, city, region
    FROM applications
    WHERE institution = '$institution'
";

$result = $conn->query($query);
$students = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
}

echo json_encode($students);
