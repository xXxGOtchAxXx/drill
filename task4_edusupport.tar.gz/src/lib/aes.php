<?php

function aes_encrypt(string $plaintext, string $keyHex): string {
    // Decode the hex key to binary
    $key = hex2bin($keyHex);
    if ($key === false || strlen($key) !== 32) {
        throw new InvalidArgumentException("Key must be a 64-hex characters string (32 bytes).");
    }

    // Generate a 16-byte (128-bit) IV for AES-256-CTR
    $iv = random_bytes(16);

    // Encrypt using AES-256-CTR
    $ciphertext = openssl_encrypt($plaintext, 'aes-256-ctr', $key, OPENSSL_RAW_DATA, $iv);

    if ($ciphertext === false) {
        throw new RuntimeException("Encryption failed.");
    }

    // Return base64(ciphertext . hex(iv))
    return base64_encode($ciphertext . bin2hex($iv));
}

function aes_decrypt(string $base64Ciphertext, string $keyHex): string {
    // Decode base64
    $data = base64_decode($base64Ciphertext, true);
    if ($data === false) {
        throw new InvalidArgumentException("Invalid base64 input.");
    }

    // The IV is stored as hex at the end, so:
    // IV length in hex = 16 bytes * 2 = 32 hex chars
    $ivHexLength = 32;

    if (strlen($data) < $ivHexLength) {
        throw new InvalidArgumentException("Input data too short.");
    }

    // Split ciphertext and IV hex string
    $ivHex = substr($data, -$ivHexLength);
    $ciphertext = substr($data, 0, strlen($data) - $ivHexLength);

    // Convert IV hex back to binary
    $iv = hex2bin($ivHex);
    if ($iv === false || strlen($iv) !== 16) {
        throw new RuntimeException("Invalid IV.");
    }

    // Decode the key
    $key = hex2bin($keyHex);
    if ($key === false || strlen($key) !== 32) {
        throw new InvalidArgumentException("Key must be a 64-hex characters string (32 bytes).");
    }

    // Decrypt
    $plaintext = openssl_decrypt($ciphertext, 'aes-256-ctr', $key, OPENSSL_RAW_DATA, $iv);

    if ($plaintext === false) {
        throw new RuntimeException("Decryption failed.");
    }

    return $plaintext;
}

// Example usage:
/*
$keyHex = '00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff'; // 32 bytes hex
$encrypted = aes_encrypt("Hello, world!", $keyHex);
echo "Encrypted: $encrypted\n";
$decrypted = aes_decrypt($encrypted, $keyHex);
echo "Decrypted: $decrypted\n";
*/
?>
