<?php
// logging.php

// Define the log path constant if not already defined
define('LOG_PATH', '/var/log/edusupport');  // default logs folder

// Ensure the log directory exists
if (!is_dir(LOG_PATH)) {
    mkdir(LOG_PATH, 0755, true);
}

// Import auth.php to get get_username()
require_once __DIR__ . '/auth.php';



/**
 * Returns client's real IP from X-Real-IP header or fallback to REMOTE_ADDR
 */
function get_real_ip() {
    if (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        return $_SERVER['HTTP_X_REAL_IP'];
    }
    return $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
}

/**
 * Write a message to the main log file with a level
 */
function log_main($level, $message) {
    $line = sprintf("%s %s %s\n", date('c'), strtoupper($level), $message);
    file_put_contents(LOG_PATH . '/main.log', $line, FILE_APPEND | LOCK_EX);
}

function debug($message) {
    log_main('DEBUG', $message);
}

function info($message) {
    log_main('INFO', $message);
}

function warning($message) {
    log_main('WARNING', $message);
}

function error($message) {
    log_main('ERROR', $message);
}

/**
 * Audit log function similar to the python stub:
 * audit_log(message, status=True, error=None, **params)
 *
 * Writes one JSON object per line to audit.jsonl with fields:
 * timestamp, ip, username, useragent, message, params, status, error
 *
 * @param string $message
 * @param bool $status true=success, false=fail
 * @param string|null $error optional error message or null
 * @param array $params extra parameters to store
 */
function audit_log(string $message, bool $status = true, ?string $error = null, ?string $username = null, array $params = []) {
    $entry = [
        'timestamp' => date('c'), // ISO 8601 format
        'ip' => get_real_ip(),
        'username' => $username ?? get_username(),
        'useragent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        'message' => $message,
        'params' => (object) $params,
        'status' => $status ? 'success' : 'fail',
        'error' => $error
    ];

    $json_line = json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";

    file_put_contents(LOG_PATH . '/audit.jsonl', $json_line, FILE_APPEND | LOCK_EX);
}
