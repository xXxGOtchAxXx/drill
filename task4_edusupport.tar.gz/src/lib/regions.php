<?php

$REGIONS = [
    'MA-01' => ['code' => 'TT', 'name' => 'Tanger-Tétouan-Al Hoceïma'],
    'MA-02' => ['code' => 'OR', 'name' => "L'Oriental"],
    'MA-03' => ['code' => 'FM', 'name' => 'Fès-Meknès'],
    'MA-04' => ['code' => 'RA', 'name' => 'Rabat-Salé-Kénitra'],
    'MA-05' => ['code' => 'BK', 'name' => 'Béni Mellal-Khénifra'],
    'MA-06' => ['code' => 'CA', 'name' => 'Casablanca-Settat'],
    'MA-07' => ['code' => 'MS', 'name' => 'Marrakech-Safi'],
    'MA-08' => ['code' => 'DT', 'name' => 'Drâa-Tafilalet'],
    'MA-09' => ['code' => 'SM', 'name' => 'Souss-Massa'],
    'MA-10' => ['code' => 'GO', 'name' => 'Guelmim-Oued Noun'],
    'MA-11' => ['code' => 'LS', 'name' => 'Laâyoune-Sakia El Hamra'],
    'MA-12' => ['code' => 'DO', 'name' => 'Dakhla-Oued Ed-Dahab'],
    'MA-99' => ['code' => 'XX', 'name' => 'Test-Region']
];

function convert_to_iso($twoLetterCode) {
    global $REGIONS;
    foreach ($REGIONS as $iso => $region) {
        if ($region['code'] === strtoupper($twoLetterCode)) {
            return $iso;
        }
    }
    return null;
}

function get_region_by_iso_code($isoCode) {
    global $REGIONS;
    return $REGIONS[$isoCode] ?? null;
}
