<?php

define('DB_HOST', getenv('DB_HOST'));
define('DB_PORT', (int) getenv('DB_PORT'));

define('APP_DB_NAME', getenv('APP_DB_NAME'));
define('APP_DB_USER', getenv('APP_DB_USER'));
define('APP_DB_PASS', getenv('APP_DB_PASS'));

define('GRADES_DB_NAME', getenv('GRADES_DB_NAME'));
define('GRADES_DB_USER', getenv('GRADES_DB_USER'));
define('GRADES_DB_PASS', getenv('GRADES_DB_PASS'));

define('STUDENT_SECRET_SUFFIX', 'S3cr3tSuff1x2025');
define('JWT_SECRET', getenv('JWT_SECRET'));
define('AES_KEY', "00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff");
?>
