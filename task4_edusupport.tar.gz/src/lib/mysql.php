<?php

require_once __DIR__ . '/config.php';

function get_connection($db) {
    switch ($db) {
        case 'edusupport':
            $dbname = APP_DB_NAME;
            $dbuser = APP_DB_USER;
            $dbpass = APP_DB_PASS;
            break;
        case 'grades':
            $dbname = GRADES_DB_NAME;
            $dbuser = GRADES_DB_USER;
            $dbpass = GRADES_DB_PASS;
            break;
        default:
            die("Unknown DB key: $db");
    }

    $conn = mysqli_connect(DB_HOST, $dbuser, $dbpass, $dbname, DB_PORT);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    return $conn;
}
?>
