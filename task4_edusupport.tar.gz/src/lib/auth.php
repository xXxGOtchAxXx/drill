<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/mysql.php';
require_once __DIR__ . '/regions.php';
require_once __DIR__ . '/jwt.php';
require_once __DIR__ . '/aes.php';


function user_info($username) {
    // Student login based on ID format
    if (preg_match('/^\d{4}[A-Z]{2}\d{6}$/', $username)) {
        $region_code = substr($username, 4, 2);
        $region_iso = convert_to_iso($region_code);
        $expected = substr(md5($username . STUDENT_SECRET_SUFFIX), 0, 16);
        if ($region_iso) {

            $user = [
                'username' => $username,
                // 'password' => $expected,
                'role' => 'student',
                'region' => $region_iso,
            ];
            return $user;
        } else {
            return [];
        }
    }

    // Agent or Institution login via DB
    $conn = get_connection('edusupport');
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        return [];
    }

    return $user;
}



function validate_login($username, $password) {
    // Student login based on ID format
    if (preg_match('/^\d{4}[A-Z]{2}\d{6}$/', $username)) {
        $region_code = substr($username, 4, 2);
        $region_iso = convert_to_iso($region_code);
        $expected = substr(md5($username . STUDENT_SECRET_SUFFIX), 0, 16);
        if ($region_iso && $expected === $password) {

            $user = [
                'username' => $username,
                //'password' => $expected,
                'role' => 'student',
                'region' => $region_iso
            ];
            $_SESSION['user'] = $user;
            return $user;
        } else {
            return [];
        }
    }

    // Agent or Institution login via DB
    $conn = get_connection('edusupport');
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        return [];
    }

    $valid = password_verify($password, $user['password']);
    if ($valid) {
        unset($user['password']);
        $_SESSION['user'] = $user;
        return $user;
    }

    return [];
}

function get_user() {
    $user =  $_SESSION['user'] ?? null;
    if ($user !== null) {
        header('X-Username: '.$user['username']);
    }
    return $user;
}

function get_username() {
    return get_user()['username'] ?? null;
}

function logout() {
    unset($_SESSION['user']);
    session_destroy();
}

function generate_token($user) {
    return aes_encrypt($user['username'], AES_KEY);
}

function validate_token($token) {
    $decoded = aes_decrypt($token, AES_KEY);
    return user_info($decoded) ?? null;
}

function get_token_user(){
    // Check auth token from Bearer token
    $headers = apache_request_headers();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    if (!preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        return null;
    }

    $token = $matches[1];
    $user = validate_token($token);
    if ($user !== null) {
        header('X-Username: '.$user['username']);
    }

    return $user;
}