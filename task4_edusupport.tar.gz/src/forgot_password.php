<?php
require_once __DIR__ . '/lib/auth.php';

$user = get_user();
if ($user) {
    if ($user['role'] === 'student') {
        header('Location: /views/student.php');
        exit;
    } elseif ($user['role'] === 'agent') {
        header('Location: /views/agent.php');
        exit;
    } elseif ($user['role'] === 'institution') {
        header('Location: /views/institution.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>EduSupport Forgot Password</title>
    <link href="/static/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="card-title text-center mb-4">Forgot Password</h4>
                    <div id="error" class="alert alert-danger d-none" role="alert"></div>
                    <form id="loginForm">
                        <div class="mb-3">
                            <label for="username" class="form-label">Student ID or Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const form = new FormData(this);
    const res = await fetch('/api/forgot_password.php', {
        method: 'POST',
        body: form
    });
    const data = await res.json();

    if (data.success) {
        alert('Password reset link is sent.')
    } else {
        const errorDiv = document.getElementById('error');
        errorDiv.classList.remove('d-none');
        errorDiv.textContent = data.message || "Request failed";
    }
});
</script>
</body>
</html>
