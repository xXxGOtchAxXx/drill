<?php
require_once __DIR__ . '/lib/auth.php';

logout();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Logging out...</title>
    <script>
        // Clear localStorage
        localStorage.removeItem('token');
        localStorage.removeItem('username');
        // Redirect to login page
        window.location.href = '/';
    </script>
</head>
<body>
</body>
</html>
