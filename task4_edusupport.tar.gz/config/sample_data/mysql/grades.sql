-- grades database schema and data

CREATE TABLE IF NOT EXISTS grades (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(20),
  subject VARCHAR(100),
  grade FLOAT CHECK (grade >= 0 AND grade <= 20)
);

-- Flag4 Grade entry
INSERT INTO grades (id, student_id, subject, grade) VALUES
(2584, 'flag_2584', 'MACERT{FLAG4}', 20.0);

-- Grade for student 2008TT512340
INSERT INTO grades (id, student_id, subject, grade) VALUES
(1, '2008TT512340', 'Regional', 9.03);

-- Grade for student 2008TT512340
INSERT INTO grades (id, student_id, subject, grade) VALUES
(2, '2008TT512340', 'Controle Continu', 13.83);

-- Grade for student 2008TT512340
INSERT INTO grades (id, student_id, subject, grade) VALUES
(3, '2008TT512340', 'National', 8.83);

-- Grade for student 2007TT354508
INSERT INTO grades (id, student_id, subject, grade) VALUES
(4, '2007TT354508', 'Regional', 10.75);

-- Grade for student 2007TT354508
INSERT INTO grades (id, student_id, subject, grade) VALUES
(5, '2007TT354508', 'Controle Continu', 18.87);

-- Grade for student 2007TT354508
INSERT INTO grades (id, student_id, subject, grade) VALUES
(6, '2007TT354508', 'National', 18.32);

-- Grade for student 2007TT565427
INSERT INTO grades (id, student_id, subject, grade) VALUES
(7, '2007TT565427', 'Regional', 15.91);

-- Grade for student 2007TT565427
INSERT INTO grades (id, student_id, subject, grade) VALUES
(8, '2007TT565427', 'Controle Continu', 12.25);

-- Grade for student 2007TT565427
INSERT INTO grades (id, student_id, subject, grade) VALUES
(9, '2007TT565427', 'National', 12.93);

-- Grade for student 2008TT839482
INSERT INTO grades (id, student_id, subject, grade) VALUES
(10, '2008TT839482', 'Regional', 11.0);

-- Grade for student 2008TT839482
INSERT INTO grades (id, student_id, subject, grade) VALUES
(11, '2008TT839482', 'Controle Continu', 19.08);

-- Grade for student 2008TT839482
INSERT INTO grades (id, student_id, subject, grade) VALUES
(12, '2008TT839482', 'National', 13.32);

-- Grade for student 2007TT971366
INSERT INTO grades (id, student_id, subject, grade) VALUES
(13, '2007TT971366', 'Regional', 12.55);

-- Grade for student 2007TT971366
INSERT INTO grades (id, student_id, subject, grade) VALUES
(14, '2007TT971366', 'Controle Continu', 19.82);

-- Grade for student 2007TT971366
INSERT INTO grades (id, student_id, subject, grade) VALUES
(15, '2007TT971366', 'National', 11.18);

-- Grade for student 2007OR096781
INSERT INTO grades (id, student_id, subject, grade) VALUES
(16, '2007OR096781', 'Regional', 14.62);

-- Grade for student 2007OR096781
INSERT INTO grades (id, student_id, subject, grade) VALUES
(17, '2007OR096781', 'Controle Continu', 13.13);

-- Grade for student 2007OR096781
INSERT INTO grades (id, student_id, subject, grade) VALUES
(18, '2007OR096781', 'National', 8.12);

-- Grade for student 2007OR875136
INSERT INTO grades (id, student_id, subject, grade) VALUES
(19, '2007OR875136', 'Regional', 18.79);

-- Grade for student 2007OR875136
INSERT INTO grades (id, student_id, subject, grade) VALUES
(20, '2007OR875136', 'Controle Continu', 10.52);

-- Grade for student 2007OR875136
INSERT INTO grades (id, student_id, subject, grade) VALUES
(21, '2007OR875136', 'National', 10.99);

-- Grade for student 2008OR650810
INSERT INTO grades (id, student_id, subject, grade) VALUES
(22, '2008OR650810', 'Regional', 17.39);

-- Grade for student 2008OR650810
INSERT INTO grades (id, student_id, subject, grade) VALUES
(23, '2008OR650810', 'Controle Continu', 12.94);

-- Grade for student 2008OR650810
INSERT INTO grades (id, student_id, subject, grade) VALUES
(24, '2008OR650810', 'National', 16.04);

-- Grade for student 2008OR914533
INSERT INTO grades (id, student_id, subject, grade) VALUES
(25, '2008OR914533', 'Regional', 10.68);

-- Grade for student 2008OR914533
INSERT INTO grades (id, student_id, subject, grade) VALUES
(26, '2008OR914533', 'Controle Continu', 15.92);

-- Grade for student 2008OR914533
INSERT INTO grades (id, student_id, subject, grade) VALUES
(27, '2008OR914533', 'National', 12.78);

-- Grade for student 2008FM727659
INSERT INTO grades (id, student_id, subject, grade) VALUES
(28, '2008FM727659', 'Regional', 8.75);

-- Grade for student 2008FM727659
INSERT INTO grades (id, student_id, subject, grade) VALUES
(29, '2008FM727659', 'Controle Continu', 17.99);

-- Grade for student 2008FM727659
INSERT INTO grades (id, student_id, subject, grade) VALUES
(30, '2008FM727659', 'National', 12.67);

-- Grade for student 2008FM500149
INSERT INTO grades (id, student_id, subject, grade) VALUES
(31, '2008FM500149', 'Regional', 13.83);

-- Grade for student 2008FM500149
INSERT INTO grades (id, student_id, subject, grade) VALUES
(32, '2008FM500149', 'Controle Continu', 12.67);

-- Grade for student 2008FM500149
INSERT INTO grades (id, student_id, subject, grade) VALUES
(33, '2008FM500149', 'National', 16.03);

-- Grade for student 2008FM620644
INSERT INTO grades (id, student_id, subject, grade) VALUES
(34, '2008FM620644', 'Regional', 12.55);

-- Grade for student 2008FM620644
INSERT INTO grades (id, student_id, subject, grade) VALUES
(35, '2008FM620644', 'Controle Continu', 10.54);

-- Grade for student 2008FM620644
INSERT INTO grades (id, student_id, subject, grade) VALUES
(36, '2008FM620644', 'National', 11.92);

-- Grade for student 2008FM020324
INSERT INTO grades (id, student_id, subject, grade) VALUES
(37, '2008FM020324', 'Regional', 18.07);

-- Grade for student 2008FM020324
INSERT INTO grades (id, student_id, subject, grade) VALUES
(38, '2008FM020324', 'Controle Continu', 15.46);

-- Grade for student 2008FM020324
INSERT INTO grades (id, student_id, subject, grade) VALUES
(39, '2008FM020324', 'National', 10.86);

-- Grade for student 2007RA862050
INSERT INTO grades (id, student_id, subject, grade) VALUES
(40, '2007RA862050', 'Regional', 9.02);

-- Grade for student 2007RA862050
INSERT INTO grades (id, student_id, subject, grade) VALUES
(41, '2007RA862050', 'Controle Continu', 10.98);

-- Grade for student 2007RA862050
INSERT INTO grades (id, student_id, subject, grade) VALUES
(42, '2007RA862050', 'National', 14.7);

-- Grade for student 2008RA311797
INSERT INTO grades (id, student_id, subject, grade) VALUES
(43, '2008RA311797', 'Regional', 9.88);

-- Grade for student 2008RA311797
INSERT INTO grades (id, student_id, subject, grade) VALUES
(44, '2008RA311797', 'Controle Continu', 10.09);

-- Grade for student 2008RA311797
INSERT INTO grades (id, student_id, subject, grade) VALUES
(45, '2008RA311797', 'National', 8.9);

-- Grade for student 2007RA571015
INSERT INTO grades (id, student_id, subject, grade) VALUES
(46, '2007RA571015', 'Regional', 15.14);

-- Grade for student 2007RA571015
INSERT INTO grades (id, student_id, subject, grade) VALUES
(47, '2007RA571015', 'Controle Continu', 17.89);

-- Grade for student 2007RA571015
INSERT INTO grades (id, student_id, subject, grade) VALUES
(48, '2007RA571015', 'National', 19.05);

-- Grade for student 2008RA604238
INSERT INTO grades (id, student_id, subject, grade) VALUES
(49, '2008RA604238', 'Regional', 15.62);

-- Grade for student 2008RA604238
INSERT INTO grades (id, student_id, subject, grade) VALUES
(50, '2008RA604238', 'Controle Continu', 13.9);

-- Grade for student 2008RA604238
INSERT INTO grades (id, student_id, subject, grade) VALUES
(51, '2008RA604238', 'National', 9.09);

-- Grade for student 2008RA302218
INSERT INTO grades (id, student_id, subject, grade) VALUES
(52, '2008RA302218', 'Regional', 19.64);

-- Grade for student 2008RA302218
INSERT INTO grades (id, student_id, subject, grade) VALUES
(53, '2008RA302218', 'Controle Continu', 12.85);

-- Grade for student 2008RA302218
INSERT INTO grades (id, student_id, subject, grade) VALUES
(54, '2008RA302218', 'National', 14.18);

-- Grade for student 2008RA652878
INSERT INTO grades (id, student_id, subject, grade) VALUES
(55, '2008RA652878', 'Regional', 18.57);

-- Grade for student 2008RA652878
INSERT INTO grades (id, student_id, subject, grade) VALUES
(56, '2008RA652878', 'Controle Continu', 13.82);

-- Grade for student 2008RA652878
INSERT INTO grades (id, student_id, subject, grade) VALUES
(57, '2008RA652878', 'National', 8.35);

-- Grade for student 2007RA235615
INSERT INTO grades (id, student_id, subject, grade) VALUES
(58, '2007RA235615', 'Regional', 19.76);

-- Grade for student 2007RA235615
INSERT INTO grades (id, student_id, subject, grade) VALUES
(59, '2007RA235615', 'Controle Continu', 10.92);

-- Grade for student 2007RA235615
INSERT INTO grades (id, student_id, subject, grade) VALUES
(60, '2007RA235615', 'National', 14.62);

-- Grade for student 2008RA361888
INSERT INTO grades (id, student_id, subject, grade) VALUES
(61, '2008RA361888', 'Regional', 14.86);

-- Grade for student 2008RA361888
INSERT INTO grades (id, student_id, subject, grade) VALUES
(62, '2008RA361888', 'Controle Continu', 10.8);

-- Grade for student 2008RA361888
INSERT INTO grades (id, student_id, subject, grade) VALUES
(63, '2008RA361888', 'National', 17.31);

-- Grade for student 2008RA404832
INSERT INTO grades (id, student_id, subject, grade) VALUES
(64, '2008RA404832', 'Regional', 8.18);

-- Grade for student 2008RA404832
INSERT INTO grades (id, student_id, subject, grade) VALUES
(65, '2008RA404832', 'Controle Continu', 9.73);

-- Grade for student 2008RA404832
INSERT INTO grades (id, student_id, subject, grade) VALUES
(66, '2008RA404832', 'National', 18.45);

-- Grade for student 2007RA893140
INSERT INTO grades (id, student_id, subject, grade) VALUES
(67, '2007RA893140', 'Regional', 15.57);

-- Grade for student 2007RA893140
INSERT INTO grades (id, student_id, subject, grade) VALUES
(68, '2007RA893140', 'Controle Continu', 19.05);

-- Grade for student 2007RA893140
INSERT INTO grades (id, student_id, subject, grade) VALUES
(69, '2007RA893140', 'National', 19.97);

-- Grade for student 2007RA465230
INSERT INTO grades (id, student_id, subject, grade) VALUES
(70, '2007RA465230', 'Regional', 13.17);

-- Grade for student 2007RA465230
INSERT INTO grades (id, student_id, subject, grade) VALUES
(71, '2007RA465230', 'Controle Continu', 10.93);

-- Grade for student 2007RA465230
INSERT INTO grades (id, student_id, subject, grade) VALUES
(72, '2007RA465230', 'National', 12.94);

-- Grade for student 2007RA077449
INSERT INTO grades (id, student_id, subject, grade) VALUES
(73, '2007RA077449', 'Regional', 19.99);

-- Grade for student 2007RA077449
INSERT INTO grades (id, student_id, subject, grade) VALUES
(74, '2007RA077449', 'Controle Continu', 18.24);

-- Grade for student 2007RA077449
INSERT INTO grades (id, student_id, subject, grade) VALUES
(75, '2007RA077449', 'National', 9.28);

-- Grade for student 2008BK227823
INSERT INTO grades (id, student_id, subject, grade) VALUES
(76, '2008BK227823', 'Regional', 10.28);

-- Grade for student 2008BK227823
INSERT INTO grades (id, student_id, subject, grade) VALUES
(77, '2008BK227823', 'Controle Continu', 9.47);

-- Grade for student 2008BK227823
INSERT INTO grades (id, student_id, subject, grade) VALUES
(78, '2008BK227823', 'National', 18.18);

-- Grade for student 2007BK566456
INSERT INTO grades (id, student_id, subject, grade) VALUES
(79, '2007BK566456', 'Regional', 15.07);

-- Grade for student 2007BK566456
INSERT INTO grades (id, student_id, subject, grade) VALUES
(80, '2007BK566456', 'Controle Continu', 8.19);

-- Grade for student 2007BK566456
INSERT INTO grades (id, student_id, subject, grade) VALUES
(81, '2007BK566456', 'National', 11.18);

-- Grade for student 2007CA524563
INSERT INTO grades (id, student_id, subject, grade) VALUES
(82, '2007CA524563', 'Regional', 18.35);

-- Grade for student 2007CA524563
INSERT INTO grades (id, student_id, subject, grade) VALUES
(83, '2007CA524563', 'Controle Continu', 14.91);

-- Grade for student 2007CA524563
INSERT INTO grades (id, student_id, subject, grade) VALUES
(84, '2007CA524563', 'National', 14.88);

-- Grade for student 2008CA158290
INSERT INTO grades (id, student_id, subject, grade) VALUES
(85, '2008CA158290', 'Regional', 11.72);

-- Grade for student 2008CA158290
INSERT INTO grades (id, student_id, subject, grade) VALUES
(86, '2008CA158290', 'Controle Continu', 13.42);

-- Grade for student 2008CA158290
INSERT INTO grades (id, student_id, subject, grade) VALUES
(87, '2008CA158290', 'National', 8.68);

-- Grade for student 2008CA485188
INSERT INTO grades (id, student_id, subject, grade) VALUES
(88, '2008CA485188', 'Regional', 13.41);

-- Grade for student 2008CA485188
INSERT INTO grades (id, student_id, subject, grade) VALUES
(89, '2008CA485188', 'Controle Continu', 17.73);

-- Grade for student 2008CA485188
INSERT INTO grades (id, student_id, subject, grade) VALUES
(90, '2008CA485188', 'National', 18.05);

-- Grade for student 2008CA549525
INSERT INTO grades (id, student_id, subject, grade) VALUES
(91, '2008CA549525', 'Regional', 16.15);

-- Grade for student 2008CA549525
INSERT INTO grades (id, student_id, subject, grade) VALUES
(92, '2008CA549525', 'Controle Continu', 8.63);

-- Grade for student 2008CA549525
INSERT INTO grades (id, student_id, subject, grade) VALUES
(93, '2008CA549525', 'National', 15.57);

-- Grade for student 2008CA085461
INSERT INTO grades (id, student_id, subject, grade) VALUES
(94, '2008CA085461', 'Regional', 11.71);

-- Grade for student 2008CA085461
INSERT INTO grades (id, student_id, subject, grade) VALUES
(95, '2008CA085461', 'Controle Continu', 12.52);

-- Grade for student 2008CA085461
INSERT INTO grades (id, student_id, subject, grade) VALUES
(96, '2008CA085461', 'National', 17.5);

-- Grade for student 2007CA677406
INSERT INTO grades (id, student_id, subject, grade) VALUES
(97, '2007CA677406', 'Regional', 19.37);

-- Grade for student 2007CA677406
INSERT INTO grades (id, student_id, subject, grade) VALUES
(98, '2007CA677406', 'Controle Continu', 13.84);

-- Grade for student 2007CA677406
INSERT INTO grades (id, student_id, subject, grade) VALUES
(99, '2007CA677406', 'National', 10.72);

-- Grade for student 2008MS265971
INSERT INTO grades (id, student_id, subject, grade) VALUES
(100, '2008MS265971', 'Regional', 14.55);

-- Grade for student 2008MS265971
INSERT INTO grades (id, student_id, subject, grade) VALUES
(101, '2008MS265971', 'Controle Continu', 17.76);

-- Grade for student 2008MS265971
INSERT INTO grades (id, student_id, subject, grade) VALUES
(102, '2008MS265971', 'National', 10.1);

-- Grade for student 2007MS750827
INSERT INTO grades (id, student_id, subject, grade) VALUES
(103, '2007MS750827', 'Regional', 14.18);

-- Grade for student 2007MS750827
INSERT INTO grades (id, student_id, subject, grade) VALUES
(104, '2007MS750827', 'Controle Continu', 19.87);

-- Grade for student 2007MS750827
INSERT INTO grades (id, student_id, subject, grade) VALUES
(105, '2007MS750827', 'National', 14.52);

-- Grade for student 2008MS385191
INSERT INTO grades (id, student_id, subject, grade) VALUES
(106, '2008MS385191', 'Regional', 9.23);

-- Grade for student 2008MS385191
INSERT INTO grades (id, student_id, subject, grade) VALUES
(107, '2008MS385191', 'Controle Continu', 11.94);

-- Grade for student 2008MS385191
INSERT INTO grades (id, student_id, subject, grade) VALUES
(108, '2008MS385191', 'National', 11.55);

-- Grade for student 2008MS468849
INSERT INTO grades (id, student_id, subject, grade) VALUES
(109, '2008MS468849', 'Regional', 12.36);

-- Grade for student 2008MS468849
INSERT INTO grades (id, student_id, subject, grade) VALUES
(110, '2008MS468849', 'Controle Continu', 17.61);

-- Grade for student 2008MS468849
INSERT INTO grades (id, student_id, subject, grade) VALUES
(111, '2008MS468849', 'National', 16.15);

-- Grade for student 2007MS247459
INSERT INTO grades (id, student_id, subject, grade) VALUES
(112, '2007MS247459', 'Regional', 14.89);

-- Grade for student 2007MS247459
INSERT INTO grades (id, student_id, subject, grade) VALUES
(113, '2007MS247459', 'Controle Continu', 14.35);

-- Grade for student 2007MS247459
INSERT INTO grades (id, student_id, subject, grade) VALUES
(114, '2007MS247459', 'National', 12.78);

-- Grade for student 2007MS474001
INSERT INTO grades (id, student_id, subject, grade) VALUES
(115, '2007MS474001', 'Regional', 18.7);

-- Grade for student 2007MS474001
INSERT INTO grades (id, student_id, subject, grade) VALUES
(116, '2007MS474001', 'Controle Continu', 18.22);

-- Grade for student 2007MS474001
INSERT INTO grades (id, student_id, subject, grade) VALUES
(117, '2007MS474001', 'National', 16.54);

-- Grade for student 2007MS248235
INSERT INTO grades (id, student_id, subject, grade) VALUES
(118, '2007MS248235', 'Regional', 20.0);

-- Grade for student 2007MS248235
INSERT INTO grades (id, student_id, subject, grade) VALUES
(119, '2007MS248235', 'Controle Continu', 16.63);

-- Grade for student 2007MS248235
INSERT INTO grades (id, student_id, subject, grade) VALUES
(120, '2007MS248235', 'National', 14.31);

-- Grade for student 2008MS673540
INSERT INTO grades (id, student_id, subject, grade) VALUES
(121, '2008MS673540', 'Regional', 17.98);

-- Grade for student 2008MS673540
INSERT INTO grades (id, student_id, subject, grade) VALUES
(122, '2008MS673540', 'Controle Continu', 14.22);

-- Grade for student 2008MS673540
INSERT INTO grades (id, student_id, subject, grade) VALUES
(123, '2008MS673540', 'National', 11.65);

-- Grade for student 2007DT334617
INSERT INTO grades (id, student_id, subject, grade) VALUES
(124, '2007DT334617', 'Regional', 19.34);

-- Grade for student 2007DT334617
INSERT INTO grades (id, student_id, subject, grade) VALUES
(125, '2007DT334617', 'Controle Continu', 18.37);

-- Grade for student 2007DT334617
INSERT INTO grades (id, student_id, subject, grade) VALUES
(126, '2007DT334617', 'National', 13.02);

-- Grade for student 2007DT800190
INSERT INTO grades (id, student_id, subject, grade) VALUES
(127, '2007DT800190', 'Regional', 14.07);

-- Grade for student 2007DT800190
INSERT INTO grades (id, student_id, subject, grade) VALUES
(128, '2007DT800190', 'Controle Continu', 19.6);

-- Grade for student 2007DT800190
INSERT INTO grades (id, student_id, subject, grade) VALUES
(129, '2007DT800190', 'National', 10.58);

-- Grade for student 2008DT299628
INSERT INTO grades (id, student_id, subject, grade) VALUES
(130, '2008DT299628', 'Regional', 8.54);

-- Grade for student 2008DT299628
INSERT INTO grades (id, student_id, subject, grade) VALUES
(131, '2008DT299628', 'Controle Continu', 8.61);

-- Grade for student 2008DT299628
INSERT INTO grades (id, student_id, subject, grade) VALUES
(132, '2008DT299628', 'National', 14.74);

-- Grade for student 2007SM292559
INSERT INTO grades (id, student_id, subject, grade) VALUES
(133, '2007SM292559', 'Regional', 14.73);

-- Grade for student 2007SM292559
INSERT INTO grades (id, student_id, subject, grade) VALUES
(134, '2007SM292559', 'Controle Continu', 19.21);

-- Grade for student 2007SM292559
INSERT INTO grades (id, student_id, subject, grade) VALUES
(135, '2007SM292559', 'National', 16.66);

-- Grade for student 2007SM114532
INSERT INTO grades (id, student_id, subject, grade) VALUES
(136, '2007SM114532', 'Regional', 16.61);

-- Grade for student 2007SM114532
INSERT INTO grades (id, student_id, subject, grade) VALUES
(137, '2007SM114532', 'Controle Continu', 9.21);

-- Grade for student 2007SM114532
INSERT INTO grades (id, student_id, subject, grade) VALUES
(138, '2007SM114532', 'National', 17.25);

-- Grade for student 2008SM684607
INSERT INTO grades (id, student_id, subject, grade) VALUES
(139, '2008SM684607', 'Regional', 15.83);

-- Grade for student 2008SM684607
INSERT INTO grades (id, student_id, subject, grade) VALUES
(140, '2008SM684607', 'Controle Continu', 10.79);

-- Grade for student 2008SM684607
INSERT INTO grades (id, student_id, subject, grade) VALUES
(141, '2008SM684607', 'National', 16.86);

-- Grade for student 2007SM876822
INSERT INTO grades (id, student_id, subject, grade) VALUES
(142, '2007SM876822', 'Regional', 19.14);

-- Grade for student 2007SM876822
INSERT INTO grades (id, student_id, subject, grade) VALUES
(143, '2007SM876822', 'Controle Continu', 12.02);

-- Grade for student 2007SM876822
INSERT INTO grades (id, student_id, subject, grade) VALUES
(144, '2007SM876822', 'National', 13.45);

-- Grade for student 2007GO600521
INSERT INTO grades (id, student_id, subject, grade) VALUES
(145, '2007GO600521', 'Regional', 9.09);

-- Grade for student 2007GO600521
INSERT INTO grades (id, student_id, subject, grade) VALUES
(146, '2007GO600521', 'Controle Continu', 14.12);

-- Grade for student 2007GO600521
INSERT INTO grades (id, student_id, subject, grade) VALUES
(147, '2007GO600521', 'National', 17.7);

-- Grade for student 2007GO979134
INSERT INTO grades (id, student_id, subject, grade) VALUES
(148, '2007GO979134', 'Regional', 13.38);

-- Grade for student 2007GO979134
INSERT INTO grades (id, student_id, subject, grade) VALUES
(149, '2007GO979134', 'Controle Continu', 19.01);

-- Grade for student 2007GO979134
INSERT INTO grades (id, student_id, subject, grade) VALUES
(150, '2007GO979134', 'National', 12.53);

-- Grade for student 2007LS314455
INSERT INTO grades (id, student_id, subject, grade) VALUES
(151, '2007LS314455', 'Regional', 17.67);

-- Grade for student 2007LS314455
INSERT INTO grades (id, student_id, subject, grade) VALUES
(152, '2007LS314455', 'Controle Continu', 18.98);

-- Grade for student 2007LS314455
INSERT INTO grades (id, student_id, subject, grade) VALUES
(153, '2007LS314455', 'National', 14.75);

-- Grade for student 2008DO580189
INSERT INTO grades (id, student_id, subject, grade) VALUES
(154, '2008DO580189', 'Regional', 14.84);

-- Grade for student 2008DO580189
INSERT INTO grades (id, student_id, subject, grade) VALUES
(155, '2008DO580189', 'Controle Continu', 10.95);

-- Grade for student 2008DO580189
INSERT INTO grades (id, student_id, subject, grade) VALUES
(156, '2008DO580189', 'National', 14.61);

-- Grade for student 2007XX828897
INSERT INTO grades (id, student_id, subject, grade) VALUES
(157, '2007XX828897', 'Regional', 15.26);

-- Grade for student 2007XX828897
INSERT INTO grades (id, student_id, subject, grade) VALUES
(158, '2007XX828897', 'Controle Continu', 15.37);

-- Grade for student 2007XX828897
INSERT INTO grades (id, student_id, subject, grade) VALUES
(159, '2007XX828897', 'National', 15.15);

-- Grade for student 2008XX579902
INSERT INTO grades (id, student_id, subject, grade) VALUES
(160, '2008XX579902', 'Regional', 11.22);

-- Grade for student 2008XX579902
INSERT INTO grades (id, student_id, subject, grade) VALUES
(161, '2008XX579902', 'Controle Continu', 12.56);

-- Grade for student 2008XX579902
INSERT INTO grades (id, student_id, subject, grade) VALUES
(162, '2008XX579902', 'National', 17.41);

-- Grade for student 2007XX005447
INSERT INTO grades (id, student_id, subject, grade) VALUES
(163, '2007XX005447', 'Regional', 14.68);

-- Grade for student 2007XX005447
INSERT INTO grades (id, student_id, subject, grade) VALUES
(164, '2007XX005447', 'Controle Continu', 14.15);

-- Grade for student 2007XX005447
INSERT INTO grades (id, student_id, subject, grade) VALUES
(165, '2007XX005447', 'National', 9.24);

