-- edusupport database schema and data

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE,
  password VARCHAR(64),
  role ENUM ('agent', 'institution'),
  region VARCHAR(10),
  display_name VARCHAR(64) DEFAULT NULL,
  secret VARCHAR(64) DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(20),
  fullname VARCHAR(100),
  parent_income INT,
  institution VARCHAR(100),
  city VARCHAR(50),
  region VARCHAR(10),
  status ENUM('submitted', 'requiring_documents', 'approved', 'rejected'),
  agent_message TEXT
);

CREATE TABLE IF NOT EXISTS documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(20),
  filename VARCHAR(255),
  type ENUM('pdf', 'jpg')
);

-- Flag3 user (password: IHTfbRDoig0upKSTL)
INSERT INTO users (id, username, password, role, region, display_name, secret) VALUES
(13370, 'admin', '$2y$10$WCEvG.tBvw7tGEterQjM9urBS/lDKtFUOgCAihEBtOVNdCyyKZpSa', 'agent', '*', 'Admin', 'MACERT{FLAG3}');;

-- Flag5 application 
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(13370, '2008TT999999', 'Flag User MACERT{FLAG5}', 99999999, 'flag_institution', 'Flag City', 'MA-01', 'submitted', '');

-- Agent for region Tanger-Tétouan-Al Hoceïma (password: xH1I0Z8tITM)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(1, 'tariq.benbrahim', '$2y$10$LIX5HJA2YH.jL3k/JeA9CeWWl5LCfXHEMZWnmH3zPOtS6oYILWEoK', 'agent', 'MA-01', 'Tariq Benbrahim');

-- Institution Al Fath in region_name='Tanger-Tétouan-Al Hoceïma' inst_object['city']='Tanger' (password: kNIx19kLvTI)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(2, 'al_fath', '$2y$10$MKm1sqfJu350Jsv/Bu1ZmeStbnvRYFlQrlzBT1IZPztfg6PjnfLBW', 'institution', 'MA-01', 'Al Fath');

INSERT INTO documents (id, student_id, filename, type) VALUES
(1, '2008TT512340', '2008TT512340_proof_parent_income.pdf', 'pdf');

-- Application for student 2008TT512340 (pwd: b3ca07bcd1e47490)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(1, '2008TT512340', 'Youssef Harfi', 2973, 'al_fath', 'Tanger', 'MA-01', 'requiring_documents', 'Additional documents required from student.');

-- Institution Ibn Khaldoun in region_name='Tanger-Tétouan-Al Hoceïma' inst_object['city']='Al Hoceïma' (password: iU9wHoUEAK4)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(3, 'ibn_khaldoun', '$2y$10$P49TT8DZ6bxj2Ee0wzRlyu4Hinag/uVZb4ow4xNIp1ziCRIrOH8uC', 'institution', 'MA-01', 'Ibn Khaldoun');

INSERT INTO documents (id, student_id, filename, type) VALUES
(2, '2007TT277932', '2007TT277932_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(3, '2007TT277932', '2007TT277932_etat_civil.pdf', 'pdf');

-- Application for student 2007TT277932 (pwd: 82e3dbd4ef2b34a6)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(2, '2007TT277932', 'Meryem Ezzarhouni', 3466, 'ibn_khaldoun', 'Al Hoceïma', 'MA-01', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(4, '2007TT354508', '2007TT354508_etat_civil.pdf', 'pdf');

-- Application for student 2007TT354508 (pwd: 8c00f2a8df15e744)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(3, '2007TT354508', 'Youssef Bouziane', 4537, 'ibn_khaldoun', 'Al Hoceïma', 'MA-01', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(5, '2007TT565427', '2007TT565427_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(6, '2007TT565427', '2007TT565427_etat_civil.pdf', 'pdf');

-- Application for student 2007TT565427 (pwd: 46f07a9bcf8cd3df)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(4, '2007TT565427', 'Imane Idlhou', 4677, 'ibn_khaldoun', 'Al Hoceïma', 'MA-01', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(7, '2008TT839482', '2008TT839482_proof_parent_income.pdf', 'pdf');

-- Application for student 2008TT839482 (pwd: 1319bab8b781ae7d)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(5, '2008TT839482', 'Hassan Ouahbi', 1569, 'ibn_khaldoun', 'Al Hoceïma', 'MA-01', 'requiring_documents', 'Additional documents required from student.');

-- Institution Anwal in region_name='Tanger-Tétouan-Al Hoceïma' inst_object['city']='Tétouan' (password: 1qaINgSqH8Q)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(4, 'anwal', '$2y$10$ViXr01I0uZiGdwCc.r4gGePM7wJxeFWEIIfy/I0HNbPpLambEqUWa', 'institution', 'MA-01', 'Anwal');

INSERT INTO documents (id, student_id, filename, type) VALUES
(8, '2007TT971366', '2007TT971366_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(9, '2007TT971366', '2007TT971366_etat_civil.pdf', 'pdf');

-- Application for student 2007TT971366 (pwd: 5b7e011ebefafb9f)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(6, '2007TT971366', 'Amina Mazouz', 3329, 'anwal', 'Tétouan', 'MA-01', 'rejected', 'Application rejected with score 11.71 (threshold 12).');

-- Agent for region L'Oriental (password: dldnDdTPw2t)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(5, 'asma.aitmoussa', '$2y$10$Gt3HcokU9/jvs5DjfyfrAuLFqy8BAzN4Ks3ssVXXY.s6u6siG37Aa', 'agent', 'MA-02', 'Asma Ait Moussa');

-- Institution Zaitouna in region_name="L'Oriental" inst_object['city']='Berkane' (password: BtqfPttJqO9)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(6, 'zaitouna', '$2y$10$MY2tyXkfrlEhU75/86kesOeRcb9adZxV0heIrmZAelY3tTjNJvc3G', 'institution', 'MA-02', 'Zaitouna');

INSERT INTO documents (id, student_id, filename, type) VALUES
(10, '2007OR096781', '2007OR096781_etat_civil.pdf', 'pdf');

-- Application for student 2007OR096781 (pwd: 01b544beedbaee5a)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(7, '2007OR096781', 'Nawal Ziani', 361, 'zaitouna', 'Berkane', 'MA-02', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(11, '2007OR875136', '2007OR875136_etat_civil.pdf', 'pdf');

-- Application for student 2007OR875136 (pwd: cf62e86b85084471)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(8, '2007OR875136', 'Leila Bouziane', 4526, 'zaitouna', 'Berkane', 'MA-02', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(12, '2008OR650810', '2008OR650810_proof_parent_income.pdf', 'pdf');

-- Application for student 2008OR650810 (pwd: ee012e737468d1ad)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(9, '2008OR650810', 'Nour Ouahbi', 1331, 'zaitouna', 'Berkane', 'MA-02', 'requiring_documents', 'Additional documents required from student.');

-- Institution Al Jazari in region_name="L'Oriental" inst_object['city']='Oujda' (password: ROja9LhY4LZ)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(7, 'al_jazari', '$2y$10$JhPmyj7RJhU5QhUQopzsY.h8RVcSIaH1RhCw97NXW60gCsRrmHSge', 'institution', 'MA-02', 'Al Jazari');

INSERT INTO documents (id, student_id, filename, type) VALUES
(13, '2008OR914533', '2008OR914533_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(14, '2008OR914533', '2008OR914533_etat_civil.pdf', 'pdf');

-- Application for student 2008OR914533 (pwd: 099e74446e146bde)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(10, '2008OR914533', 'Ahmed Oul Taleb', 1822, 'al_jazari', 'Oujda', 'MA-02', 'approved', 'Application approved with score 13.53 (threshold 13).');

-- Agent for region Fès-Meknès (password: t7LqAa4lgDT)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(8, 'yassine.lahlou', '$2y$10$Le5U8yyb749.LgOTMHsj5ebKL1BGHiFAau3vYT/xONK7Ne05vSiJS', 'agent', 'MA-03', 'Yassine Lahlou');

-- Institution Al Arqam in region_name='Fès-Meknès' inst_object['city']='Ifrane' (password: FXuIxdlRPP4)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(9, 'al_arqam', '$2y$10$I1HWlmU0OWcgRIFBFfeh1u5vsv0ZvkSAJlP6TuZ1.5X2TJbykelZK', 'institution', 'MA-03', 'Al Arqam');

-- Application for student 2008FM657193 (pwd: b6537afef98c63aa)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(11, '2008FM657193', 'Amina Ziani', 3603, 'al_arqam', 'Ifrane', 'MA-03', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(15, '2008FM727659', '2008FM727659_proof_parent_income.pdf', 'pdf');

-- Application for student 2008FM727659 (pwd: 9cd6cc00f59615c7)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(12, '2008FM727659', 'Nour Ait Baha', 1752, 'al_arqam', 'Ifrane', 'MA-03', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(16, '2008FM500149', '2008FM500149_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(17, '2008FM500149', '2008FM500149_etat_civil.pdf', 'pdf');

-- Application for student 2008FM500149 (pwd: 199f3768ae06c5ee)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(13, '2008FM500149', 'Mohamed Benbrahim', 2446, 'al_arqam', 'Ifrane', 'MA-03', 'rejected', 'Application rejected with score 13.01 (threshold 14).');

-- Institution Daraa in region_name='Fès-Meknès' inst_object['city']='Ifrane' (password: PoMfrtZ7p2O)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(10, 'daraa', '$2y$10$aimGvbk7q8XpKGvjZR83nefGagMroLJvUyTLeAAN0QNLoVy48WrVm', 'institution', 'MA-03', 'Daraa');

INSERT INTO documents (id, student_id, filename, type) VALUES
(18, '2008FM620644', '2008FM620644_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(19, '2008FM620644', '2008FM620644_etat_civil.pdf', 'pdf');

-- Application for student 2008FM620644 (pwd: 4d48d89f7ab860ce)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(14, '2008FM620644', 'Jamal Ait Moussa', 222, 'daraa', 'Ifrane', 'MA-03', 'approved', 'Application approved with score 15.46 (threshold 14).');

-- Institution Mohammed V in region_name='Fès-Meknès' inst_object['city']='Ifrane' (password: wAh4nWRXIC1)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(11, 'mohammed_v', '$2y$10$4CHUn.ci3pCRv2MBqQ88iusoPi7quGWGBsFqU3Z.dXD.hH4L05di6', 'institution', 'MA-03', 'Mohammed V');

INSERT INTO documents (id, student_id, filename, type) VALUES
(20, '2008FM020324', '2008FM020324_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(21, '2008FM020324', '2008FM020324_etat_civil.pdf', 'pdf');

-- Application for student 2008FM020324 (pwd: 2f0d2d69f75eab29)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(15, '2008FM020324', 'Yassine Cherkaoui', 2866, 'mohammed_v', 'Ifrane', 'MA-03', 'rejected', 'Application rejected with score 12.62 (threshold 14).');

-- Agent for region Rabat-Salé-Kénitra (password: 5JJtk1t4xTW)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(12, 'leila.mazouz', '$2y$10$IgJgFjXesHqKygVz9ZJTauMKWyjQZ5Yj3FOlaOzJlcEtM6u3IeMkK', 'agent', 'MA-04', 'Leila Mazouz');

-- Institution Al Fath in region_name='Rabat-Salé-Kénitra' inst_object['city']='Rabat' (password: CnP1w3AOjkG)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(13, 'al_fath2', '$2y$10$RyVcenEkopWyumI.CD0ra.HBY1Ca9G7vnufmbtUT9epUmwGyhBhNC', 'institution', 'MA-04', 'Al Fath');

INSERT INTO documents (id, student_id, filename, type) VALUES
(22, '2007RA862050', '2007RA862050_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(23, '2007RA862050', '2007RA862050_etat_civil.pdf', 'pdf');

-- Application for student 2007RA862050 (pwd: 29f6b4ae25a6fd3a)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(16, '2007RA862050', 'Fatima Ait Benali', 4028, 'al_fath2', 'Rabat', 'MA-04', 'rejected', 'Application rejected with score 9.07 (threshold 13).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(24, '2008RA311797', '2008RA311797_etat_civil.pdf', 'pdf');

-- Application for student 2008RA311797 (pwd: cfbd3a65f312c634)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(17, '2008RA311797', 'Hanane Ait Ouarasse', 2501, 'al_fath2', 'Rabat', 'MA-04', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(25, '2008RA034225', '2008RA034225_proof_parent_income.pdf', 'pdf');

-- Application for student 2008RA034225 (pwd: 5778b52ff4692c89)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(18, '2008RA034225', 'Zakaria Alami', 5791, 'al_fath2', 'Rabat', 'MA-04', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(26, '2007RA571015', '2007RA571015_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(27, '2007RA571015', '2007RA571015_etat_civil.pdf', 'pdf');

-- Application for student 2007RA571015 (pwd: f546d9cfcc73a593)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(19, '2007RA571015', 'Zakaria Amghar', 1220, 'al_fath2', 'Rabat', 'MA-04', 'approved', 'Application approved with score 16.65 (threshold 13).');

-- Institution Al Qods in region_name='Rabat-Salé-Kénitra' inst_object['city']='Kénitra' (password: uE6KvVrutqE)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(14, 'al_qods', '$2y$10$P8EiC6JkVhC1wTzPz.56Ke6n.7JcVLE7UU60byrGt.R4sXA1tytfK', 'institution', 'MA-04', 'Al Qods');

INSERT INTO documents (id, student_id, filename, type) VALUES
(28, '2008RA084349', '2008RA084349_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(29, '2008RA084349', '2008RA084349_etat_civil.pdf', 'pdf');

-- Application for student 2008RA084349 (pwd: 70a2953c7ffbe37d)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(20, '2008RA084349', 'Karim Fassi', 3539, 'al_qods', 'Kénitra', 'MA-04', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(30, '2008RA604238', '2008RA604238_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(31, '2008RA604238', '2008RA604238_etat_civil.pdf', 'pdf');

-- Application for student 2008RA604238 (pwd: 344652d056245652)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(21, '2008RA604238', 'Ahmed Ibourka', 1435, 'al_qods', 'Kénitra', 'MA-04', 'approved', 'Application approved with score 14.04 (threshold 13).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(32, '2008RA302218', '2008RA302218_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(33, '2008RA302218', '2008RA302218_etat_civil.pdf', 'pdf');

-- Application for student 2008RA302218 (pwd: ec9df2b925bd2f51)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(22, '2008RA302218', 'Souad Ibourka', 4506, 'al_qods', 'Kénitra', 'MA-04', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(34, '2008RA652878', '2008RA652878_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(35, '2008RA652878', '2008RA652878_etat_civil.pdf', 'pdf');

-- Application for student 2008RA652878 (pwd: 7e3fe1494e7f781c)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(23, '2008RA652878', 'Ayoub Ait Ahmed', 3621, 'al_qods', 'Kénitra', 'MA-04', 'requiring_documents', 'Additional documents required from student.');

-- Institution Atlas in region_name='Rabat-Salé-Kénitra' inst_object['city']='Rabat' (password: UAG3WDmsuRK)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(15, 'atlas', '$2y$10$numdF4RnJCh7cmYMtLsSKu92AGKOrNEWRzfWyaGbmc1E1F5vrNVwC', 'institution', 'MA-04', 'Atlas');

INSERT INTO documents (id, student_id, filename, type) VALUES
(36, '2007RA235615', '2007RA235615_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(37, '2007RA235615', '2007RA235615_etat_civil.pdf', 'pdf');

-- Application for student 2007RA235615 (pwd: 3fa81972188fbec3)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(24, '2007RA235615', 'Sara El Ma', 962, 'atlas', 'Rabat', 'MA-04', 'approved', 'Application approved with score 15.95 (threshold 13).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(38, '2008RA810208', '2008RA810208_proof_parent_income.pdf', 'pdf');

-- Application for student 2008RA810208 (pwd: 46799f03141c4797)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(25, '2008RA810208', 'Abdel Lahlou', 4159, 'atlas', 'Rabat', 'MA-04', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(39, '2008RA361888', '2008RA361888_etat_civil.pdf', 'pdf');

-- Application for student 2008RA361888 (pwd: 714e9a9c01afb5ad)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(26, '2008RA361888', 'Zineb Oulhaj', 4451, 'atlas', 'Rabat', 'MA-04', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(40, '2008RA404832', '2008RA404832_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(41, '2008RA404832', '2008RA404832_etat_civil.pdf', 'pdf');

-- Application for student 2008RA404832 (pwd: 0d33b26db8caaa73)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(27, '2008RA404832', 'Nour El Hachimi', 303, 'atlas', 'Rabat', 'MA-04', 'approved', 'Application approved with score 15.55 (threshold 13).');

-- Institution Al Arqam in region_name='Rabat-Salé-Kénitra' inst_object['city']='Kénitra' (password: wZhcdtsJR1s)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(16, 'al_arqam2', '$2y$10$xfpQvmdEj2ZEJmCfsyHddO6HKEHyjAOfhBuxv4r8cjDDI2R19NFBi', 'institution', 'MA-04', 'Al Arqam');

INSERT INTO documents (id, student_id, filename, type) VALUES
(42, '2007RA893140', '2007RA893140_proof_parent_income.pdf', 'pdf');

-- Application for student 2007RA893140 (pwd: dc2555ee66a8ac0a)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(28, '2007RA893140', 'Zineb Idrassen', 4371, 'al_arqam2', 'Kénitra', 'MA-04', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(43, '2007RA465230', '2007RA465230_proof_parent_income.pdf', 'pdf');

-- Application for student 2007RA465230 (pwd: 6c81be118ad7be5b)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(29, '2007RA465230', 'Amine Tazaghart', 2453, 'al_arqam2', 'Kénitra', 'MA-04', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(44, '2008RA649813', '2008RA649813_etat_civil.pdf', 'pdf');

-- Application for student 2008RA649813 (pwd: f3c9d0a6713aba42)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(30, '2008RA649813', 'Amina El Hachimi', 4777, 'al_arqam2', 'Kénitra', 'MA-04', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(45, '2007RA077449', '2007RA077449_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(46, '2007RA077449', '2007RA077449_etat_civil.pdf', 'pdf');

-- Application for student 2007RA077449 (pwd: 3820c271ff95c6e6)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(31, '2007RA077449', 'Reda Benbrahim', 4813, 'al_arqam2', 'Kénitra', 'MA-04', 'requiring_documents', 'Additional documents required from student.');

-- Agent for region Béni Mellal-Khénifra (password: noSW3aZ0UX4)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(17, 'souad.ziani', '$2y$10$O9Qu/VLv7EztQYRLXX8bQOC58gwJuK2MTHfFs2VgTUYwCDESTf7vO', 'agent', 'MA-05', 'Souad Ziani');

-- Institution Omar Ibn Al Khattab in region_name='Béni Mellal-Khénifra' inst_object['city']='Khénifra' (password: qw2k4xmN2WF)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(18, 'omar_ibn_al_khattab', '$2y$10$ZSRMy0UqRnOS7WVvnlGv6.c8bcqU/am3.Z0JSf4xx2ThA1HxlUD22', 'institution', 'MA-05', 'Omar Ibn Al Khattab');

INSERT INTO documents (id, student_id, filename, type) VALUES
(47, '2008BK475679', '2008BK475679_proof_parent_income.pdf', 'pdf');

-- Application for student 2008BK475679 (pwd: c42fbae21344c42b)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(32, '2008BK475679', 'Leila Ait Moussa', 5705, 'omar_ibn_al_khattab', 'Khénifra', 'MA-05', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(48, '2008BK227823', '2008BK227823_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(49, '2008BK227823', '2008BK227823_etat_civil.pdf', 'pdf');

-- Application for student 2008BK227823 (pwd: da44c245529f06ca)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(33, '2008BK227823', 'Reda Amzian', 1934, 'omar_ibn_al_khattab', 'Khénifra', 'MA-05', 'requiring_documents', 'Additional documents required from student.');

-- Institution Abdelkrim El Khattabi in region_name='Béni Mellal-Khénifra' inst_object['city']='Béni Mellal' (password: bgYoI46oLK2)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(19, 'abdelkrim_el_khattabi', '$2y$10$y7G/OItKBsBR4qajPMXMU.S9kwUCbP7OiJlP3EOsgOlH81J/ts8WK', 'institution', 'MA-05', 'Abdelkrim El Khattabi');

INSERT INTO documents (id, student_id, filename, type) VALUES
(50, '2007BK132040', '2007BK132040_etat_civil.pdf', 'pdf');

-- Application for student 2007BK132040 (pwd: 02a91ce83654ec56)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(34, '2007BK132040', 'Jamal Boukhari', 562, 'abdelkrim_el_khattabi', 'Béni Mellal', 'MA-05', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(51, '2007BK566456', '2007BK566456_etat_civil.pdf', 'pdf');

-- Application for student 2007BK566456 (pwd: e22d1b60b40f9ea3)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(35, '2007BK566456', 'Said El Khatib', 900, 'abdelkrim_el_khattabi', 'Béni Mellal', 'MA-05', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(52, '2007BK499380', '2007BK499380_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(53, '2007BK499380', '2007BK499380_etat_civil.pdf', 'pdf');

-- Application for student 2007BK499380 (pwd: 54ff8d2d2f4f5fcd)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(36, '2007BK499380', 'Reda Ait Mhand', 2965, 'abdelkrim_el_khattabi', 'Béni Mellal', 'MA-05', 'submitted', '');

-- Agent for region Casablanca-Settat (password: V1nNrLE4fee)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(20, 'rania.aitbenali', '$2y$10$mghAxOQBazCVh00yQZ8gQuVdyeF.H4WL57iITVZh2uIB1pcdd/VK2', 'agent', 'MA-06', 'Rania Ait Benali');

-- Institution Al Idrissi in region_name='Casablanca-Settat' inst_object['city']='Settat' (password: fDtQfnt1pX7)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(21, 'al_idrissi', '$2y$10$kVHf3ieohB2Jtl.5T543F.Mev0t9y5UCvLnwmf7L7zaliihYADAp2', 'institution', 'MA-06', 'Al Idrissi');

INSERT INTO documents (id, student_id, filename, type) VALUES
(54, '2007CA524563', '2007CA524563_proof_parent_income.pdf', 'pdf');

-- Application for student 2007CA524563 (pwd: 6850ec18b47b210b)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(37, '2007CA524563', 'Asma Ait Moussa', 2901, 'al_idrissi', 'Settat', 'MA-06', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(55, '2007CA340544', '2007CA340544_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(56, '2007CA340544', '2007CA340544_etat_civil.pdf', 'pdf');

-- Application for student 2007CA340544 (pwd: fb1838ed139a831e)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(38, '2007CA340544', 'Amine Belkouch', 3769, 'al_idrissi', 'Settat', 'MA-06', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(57, '2007CA349247', '2007CA349247_proof_parent_income.pdf', 'pdf');

-- Application for student 2007CA349247 (pwd: 89b2163130466cfe)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(39, '2007CA349247', 'Amine Idrissi', 4181, 'al_idrissi', 'Settat', 'MA-06', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(58, '2007CA181926', '2007CA181926_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(59, '2007CA181926', '2007CA181926_etat_civil.pdf', 'pdf');

-- Application for student 2007CA181926 (pwd: 13a050d3452adcef)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(40, '2007CA181926', 'Karim Bouazzaoui', 5369, 'al_idrissi', 'Settat', 'MA-06', 'submitted', '');

-- Institution Imam Malik in region_name='Casablanca-Settat' inst_object['city']='Mohammedia' (password: 0LVg1OnjnJw)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(22, 'imam_malik', '$2y$10$EgcAroAUc7FAlY01oky6I.kjCcNgGClBhqYH7n8zRiYVqeV72suv.', 'institution', 'MA-06', 'Imam Malik');

INSERT INTO documents (id, student_id, filename, type) VALUES
(60, '2008CA158290', '2008CA158290_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(61, '2008CA158290', '2008CA158290_etat_civil.pdf', 'pdf');

-- Application for student 2008CA158290 (pwd: 0f192a20e7b11015)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(41, '2008CA158290', 'Reda Idrissi', 3841, 'imam_malik', 'Mohammedia', 'MA-06', 'rejected', 'Application rejected with score 9.23 (threshold 15).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(62, '2008CA485188', '2008CA485188_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(63, '2008CA485188', '2008CA485188_etat_civil.pdf', 'pdf');

-- Application for student 2008CA485188 (pwd: 1828ea0231f4eea2)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(42, '2008CA485188', 'Hanane Oulhaj', 336, 'imam_malik', 'Mohammedia', 'MA-06', 'approved', 'Application approved with score 17.64 (threshold 15).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(64, '2008CA549525', '2008CA549525_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(65, '2008CA549525', '2008CA549525_etat_civil.pdf', 'pdf');

-- Application for student 2008CA549525 (pwd: f7a382e1761c8ec4)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(43, '2008CA549525', 'Meryem Belkouch', 1300, 'imam_malik', 'Mohammedia', 'MA-06', 'rejected', 'Application rejected with score 14.56 (threshold 15).');

-- Institution Al Arqam in region_name='Casablanca-Settat' inst_object['city']='Casablanca' (password: Ce6GjfxsV8T)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(23, 'al_arqam3', '$2y$10$IanRMV9ZOvlv7LjGz5B3dOgyUOWwxWmt1.P5AnGl.5AlQNYWe34Fm', 'institution', 'MA-06', 'Al Arqam');

INSERT INTO documents (id, student_id, filename, type) VALUES
(66, '2008CA085461', '2008CA085461_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(67, '2008CA085461', '2008CA085461_etat_civil.pdf', 'pdf');

-- Application for student 2008CA085461 (pwd: 124e75817bc8e1b5)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(44, '2008CA085461', 'Hanane Ait Moussa', 1158, 'al_arqam3', 'Casablanca', 'MA-06', 'approved', 'Application approved with score 15.03 (threshold 15).');

-- Application for student 2007CA677406 (pwd: 761fd65d328324a0)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(45, '2007CA677406', 'Nawal Aziz', 2964, 'al_arqam3', 'Casablanca', 'MA-06', 'requiring_documents', 'Additional documents required from student.');

-- Institution Al Massira in region_name='Casablanca-Settat' inst_object['city']='Settat' (password: PEAQrG8hyic)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(24, 'al_massira', '$2y$10$r6QNMH7itbwk9UCtyqvSKe19F./scGfhYl47v4wZOIsIlaw5aizGG', 'institution', 'MA-06', 'Al Massira');

INSERT INTO documents (id, student_id, filename, type) VALUES
(68, '2007CA694083', '2007CA694083_proof_parent_income.pdf', 'pdf');

-- Application for student 2007CA694083 (pwd: 7ee792204d62fefd)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(46, '2007CA694083', 'Zineb Ait Mhand', 5062, 'al_massira', 'Settat', 'MA-06', 'submitted', '');

-- Agent for region Marrakech-Safi (password: L7nLW3WooU8)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(25, 'reda.fassi', '$2y$10$TpbOTAja1omAftmLBVwqGuLAWX3GTshxTBOChSU9Fx.zeNIvHqWE2', 'agent', 'MA-07', 'Reda Fassi');

-- Institution Moulay Ismail in region_name='Marrakech-Safi' inst_object['city']='Essaouira' (password: rWj8qB6dV40)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(26, 'moulay_ismail', '$2y$10$q1KpYL2BWvXZgK.wZHbJe.BX7KjWOGCfLC3rT8fS.VWgkALS6ok0O', 'institution', 'MA-07', 'Moulay Ismail');

INSERT INTO documents (id, student_id, filename, type) VALUES
(69, '2008MS265971', '2008MS265971_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(70, '2008MS265971', '2008MS265971_etat_civil.pdf', 'pdf');

-- Application for student 2008MS265971 (pwd: 1941c69ed8fc0c27)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(47, '2008MS265971', 'Youssef Benbrahim', 553, 'moulay_ismail', 'Essaouira', 'MA-07', 'approved', 'Application approved with score 16.15 (threshold 12).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(71, '2007MS750827', '2007MS750827_proof_parent_income.pdf', 'pdf');

-- Application for student 2007MS750827 (pwd: a625198bc61aab2a)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(48, '2007MS750827', 'Safae Fassi', 2403, 'moulay_ismail', 'Essaouira', 'MA-07', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(72, '2008MS904017', '2008MS904017_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(73, '2008MS904017', '2008MS904017_etat_civil.pdf', 'pdf');

-- Application for student 2008MS904017 (pwd: 4f8e2b6476a3ac7c)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(49, '2008MS904017', 'Rachid Amghar', 2719, 'moulay_ismail', 'Essaouira', 'MA-07', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(74, '2008MS385191', '2008MS385191_proof_parent_income.pdf', 'pdf');

-- Application for student 2008MS385191 (pwd: b684c7c0dcd53773)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(50, '2008MS385191', 'Meryem Ziani', 676, 'moulay_ismail', 'Essaouira', 'MA-07', 'requiring_documents', 'Additional documents required from student.');

-- Institution Oum Rabia in region_name='Marrakech-Safi' inst_object['city']='Marrakech' (password: 5riXRZRiBUw)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(27, 'oum_rabia', '$2y$10$89/VTbtI.yai/Kqoz/oTMu00grei8jk4MwVzsK17haUvCvN4K9bKK', 'institution', 'MA-07', 'Oum Rabia');

INSERT INTO documents (id, student_id, filename, type) VALUES
(75, '2008MS468849', '2008MS468849_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(76, '2008MS468849', '2008MS468849_etat_civil.pdf', 'pdf');

-- Application for student 2008MS468849 (pwd: 7d1621e4970ea40f)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(51, '2008MS468849', 'Ahmed Idlhou', 2888, 'oum_rabia', 'Marrakech', 'MA-07', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(77, '2007MS247459', '2007MS247459_proof_parent_income.pdf', 'pdf');

-- Application for student 2007MS247459 (pwd: 0a53173bc79fc564)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(52, '2007MS247459', 'Leila Chakiri', 3136, 'oum_rabia', 'Marrakech', 'MA-07', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(78, '2007MS523285', '2007MS523285_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(79, '2007MS523285', '2007MS523285_etat_civil.pdf', 'pdf');

-- Application for student 2007MS523285 (pwd: e3a41be2b8bc5a06)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(53, '2007MS523285', 'Meryem Rguibi', 4601, 'oum_rabia', 'Marrakech', 'MA-07', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(80, '2007MS474001', '2007MS474001_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(81, '2007MS474001', '2007MS474001_etat_civil.pdf', 'pdf');

-- Application for student 2007MS474001 (pwd: 6a8f54bcc6655ff0)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(54, '2007MS474001', 'Latifa Ait Baha', 3646, 'oum_rabia', 'Marrakech', 'MA-07', 'requiring_documents', 'Additional documents required from student.');

-- Institution Al Fath in region_name='Marrakech-Safi' inst_object['city']='Essaouira' (password: JH7sTNZdESz)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(28, 'al_fath3', '$2y$10$aitj/WL5JIUlDlqPVp6QX.1jiY1wu/k85Tnla12Uj4qm.aIdXamvi', 'institution', 'MA-07', 'Al Fath');

INSERT INTO documents (id, student_id, filename, type) VALUES
(82, '2007MS248235', '2007MS248235_proof_parent_income.pdf', 'pdf');

-- Application for student 2007MS248235 (pwd: 06f9c76c7ca0232f)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(55, '2007MS248235', 'Ayoub Bouhajeb', 2956, 'al_fath3', 'Essaouira', 'MA-07', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(83, '2008MS673540', '2008MS673540_etat_civil.pdf', 'pdf');

-- Application for student 2008MS673540 (pwd: f685da93ef0ecb2a)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(56, '2008MS673540', 'Fatima Amzian', 3816, 'al_fath3', 'Essaouira', 'MA-07', 'requiring_documents', 'Additional documents required from student.');

-- Agent for region Drâa-Tafilalet (password: NIkIFHsch63)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(29, 'meryem.alami', '$2y$10$iD.gkkmmvRZMRGCYIPw.ZO7t3JLzaNl5WREpQSN5qidQe2HDhBH4S', 'agent', 'MA-08', 'Meryem Alami');

-- Institution Imam Malik in region_name='Drâa-Tafilalet' inst_object['city']='Zagora' (password: HCNzAY3sp7u)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(30, 'imam_malik2', '$2y$10$h9aDS2TjTC49uSw3Hds29uGy0lo1UUkDYi3Km5HKHp4FAS7boKsCC', 'institution', 'MA-08', 'Imam Malik');

INSERT INTO documents (id, student_id, filename, type) VALUES
(84, '2007DT334617', '2007DT334617_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(85, '2007DT334617', '2007DT334617_etat_civil.pdf', 'pdf');

-- Application for student 2007DT334617 (pwd: 382721203eb70a84)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(57, '2007DT334617', 'Amina El Ma', 1003, 'imam_malik2', 'Zagora', 'MA-08', 'approved', 'Application approved with score 16.78 (threshold 14).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(86, '2007DT800190', '2007DT800190_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(87, '2007DT800190', '2007DT800190_etat_civil.pdf', 'pdf');

-- Application for student 2007DT800190 (pwd: 3dfbbde0601d34c2)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(58, '2007DT800190', 'Amine El Hachimi', 4216, 'imam_malik2', 'Zagora', 'MA-08', 'rejected', 'Application rejected with score 10.35 (threshold 14).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(88, '2008DT299628', '2008DT299628_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(89, '2008DT299628', '2008DT299628_etat_civil.pdf', 'pdf');

-- Application for student 2008DT299628 (pwd: ca74b50093313dd3)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(59, '2008DT299628', 'Yassine Elamrani', 880, 'imam_malik2', 'Zagora', 'MA-08', 'rejected', 'Application rejected with score 13.85 (threshold 14).');

-- Agent for region Souss-Massa (password: dcXUFvMFm65)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(31, 'sara.elghazali', '$2y$10$pJovhHwJCUQM77NolB8B5OV0DabpAljaH7/7slKvwywutdm09SmcG', 'agent', 'MA-09', 'Sara El Ghazali');

-- Institution Daraa in region_name='Souss-Massa' inst_object['city']='Taroudant' (password: H88QYPsRwkK)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(32, 'daraa2', '$2y$10$ji8xaWKErrCvLHQfD82cDeVEl5gxzue5PqNQa9aPFjfDuQDHR3uaq', 'institution', 'MA-09', 'Daraa');

INSERT INTO documents (id, student_id, filename, type) VALUES
(90, '2007SM292559', '2007SM292559_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(91, '2007SM292559', '2007SM292559_etat_civil.pdf', 'pdf');

-- Application for student 2007SM292559 (pwd: d9804d9613bf5cd8)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(60, '2007SM292559', 'Asma El Hilali', 1842, 'daraa2', 'Taroudant', 'MA-09', 'approved', 'Application approved with score 15.36 (threshold 13).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(92, '2008SM810616', '2008SM810616_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(93, '2008SM810616', '2008SM810616_etat_civil.pdf', 'pdf');

-- Application for student 2008SM810616 (pwd: 3929d5701fa16753)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(61, '2008SM810616', 'Nour Alami', 344, 'daraa2', 'Taroudant', 'MA-09', 'submitted', '');

-- Institution Moulay Youssef in region_name='Souss-Massa' inst_object['city']='Agadir' (password: zDSzmLBlF1b)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(33, 'moulay_youssef', '$2y$10$yY6uy0crxbkKdARP10cgVegtB6h4Etusu./vq5BOHKlGCfGorLexi', 'institution', 'MA-09', 'Moulay Youssef');

INSERT INTO documents (id, student_id, filename, type) VALUES
(94, '2007SM114532', '2007SM114532_etat_civil.pdf', 'pdf');

-- Application for student 2007SM114532 (pwd: 4c7ed0e08ac23f0e)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(62, '2007SM114532', 'Hanane Ouahbi', 1986, 'moulay_youssef', 'Agadir', 'MA-09', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(95, '2008SM684607', '2008SM684607_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(96, '2008SM684607', '2008SM684607_etat_civil.pdf', 'pdf');

-- Application for student 2008SM684607 (pwd: 47f798ba82db1cf8)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(63, '2008SM684607', 'Rania Oul Taleb', 5329, 'moulay_youssef', 'Agadir', 'MA-09', 'rejected', 'Application rejected with score 8.37 (threshold 13).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(97, '2007SM876822', '2007SM876822_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(98, '2007SM876822', '2007SM876822_etat_civil.pdf', 'pdf');

-- Application for student 2007SM876822 (pwd: d7e52d5fdde289d1)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(64, '2007SM876822', 'Souad El Hachimi', 1526, 'moulay_youssef', 'Agadir', 'MA-09', 'approved', 'Application approved with score 14.89 (threshold 13).');

-- Agent for region Guelmim-Oued Noun (password: DTpkzUCXlJ5)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(34, 'nadia.slaoui', '$2y$10$CLIDoqiktiTnzkJdUmeV1OcYIIi06w/um5H4L0uW5mb5ayUhKKO5C', 'agent', 'MA-10', 'Nadia Slaoui');

-- Institution Oum Rabia in region_name='Guelmim-Oued Noun' inst_object['city']='Tan-Tan' (password: qqBuwJ4KAhx)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(35, 'oum_rabia2', '$2y$10$t4GQwymK/GzihYZCCG5jwecd6i7RvMXUMhJE3aG62LOgNeDkUiMnu', 'institution', 'MA-10', 'Oum Rabia');

INSERT INTO documents (id, student_id, filename, type) VALUES
(99, '2007GO477079', '2007GO477079_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(100, '2007GO477079', '2007GO477079_etat_civil.pdf', 'pdf');

-- Application for student 2007GO477079 (pwd: 65ad49c05b763078)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(65, '2007GO477079', 'Karim Chakiri', 3406, 'oum_rabia2', 'Tan-Tan', 'MA-10', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(101, '2007GO600521', '2007GO600521_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(102, '2007GO600521', '2007GO600521_etat_civil.pdf', 'pdf');

-- Application for student 2007GO600521 (pwd: 57dca9a0fc426e81)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(66, '2007GO600521', 'Yassine Bouazzaoui', 1347, 'oum_rabia2', 'Tan-Tan', 'MA-10', 'approved', 'Application approved with score 14.57 (threshold 13).');

INSERT INTO documents (id, student_id, filename, type) VALUES
(103, '2008GO758414', '2008GO758414_etat_civil.pdf', 'pdf');

-- Application for student 2008GO758414 (pwd: 96db32eea91dc9e4)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(67, '2008GO758414', 'Youssef Ait Benali', 2084, 'oum_rabia2', 'Tan-Tan', 'MA-10', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(104, '2007GO979134', '2007GO979134_etat_civil.pdf', 'pdf');

-- Application for student 2007GO979134 (pwd: ef18f927b2532583)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(68, '2007GO979134', 'Rania Fassi', 2351, 'oum_rabia2', 'Tan-Tan', 'MA-10', 'requiring_documents', 'Additional documents required from student.');

-- Agent for region Laâyoune-Sakia El Hamra (password: 2ly9hDZ8C8U)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(36, 'imane.amghar', '$2y$10$AItx0Gv/gASOmz7MUNjua.3F3DaCA5XGoz.IJulpWNIM4KtLUDiTa', 'agent', 'MA-11', 'Imane Amghar');

-- Institution Fatima Al-Fihriya in region_name='Laâyoune-Sakia El Hamra' inst_object['city']='Laâyoune' (password: e6K36VBoPMz)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(37, 'fatima_al_fihriya', '$2y$10$xujAERzDwlPywfqiey8OC.SgMJTstxkw.ODyGd.0hbiZcd5/whr8e', 'institution', 'MA-11', 'Fatima Al-Fihriya');

INSERT INTO documents (id, student_id, filename, type) VALUES
(105, '2007LS433649', '2007LS433649_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(106, '2007LS433649', '2007LS433649_etat_civil.pdf', 'pdf');

-- Application for student 2007LS433649 (pwd: ed1bf212baf2706d)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(69, '2007LS433649', 'Malika Ziani', 499, 'fatima_al_fihriya', 'Laâyoune', 'MA-11', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(107, '2007LS314455', '2007LS314455_proof_parent_income.pdf', 'pdf');

-- Application for student 2007LS314455 (pwd: 06957d68737469f9)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(70, '2007LS314455', 'Ismail El Khatib', 4406, 'fatima_al_fihriya', 'Laâyoune', 'MA-11', 'requiring_documents', 'Additional documents required from student.');

-- Agent for region Dakhla-Oued Ed-Dahab (password: fSg01LlPq5K)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(38, 'amina.mansouri', '$2y$10$L5sUMehqIyjpW1L.NiIOh.jqSFpKgkBNbFvVtoJ9eI523SNlJin8K', 'agent', 'MA-12', 'Amina Mansouri');

-- Institution Fatima Al-Fihriya in region_name='Dakhla-Oued Ed-Dahab' inst_object['city']='Dakhla' (password: yWt9RthOrCo)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(39, 'fatima_al_fihriya2', '$2y$10$gUGVI50538rUB9hPdjku7uibAv5CBIYqJkt2WES48QG7wxina89SK', 'institution', 'MA-12', 'Fatima Al-Fihriya');

INSERT INTO documents (id, student_id, filename, type) VALUES
(108, '2008DO580189', '2008DO580189_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(109, '2008DO580189', '2008DO580189_etat_civil.pdf', 'pdf');

-- Application for student 2008DO580189 (pwd: 52297f06f3996744)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(71, '2008DO580189', 'Hanane Bouziane', 5898, 'fatima_al_fihriya2', 'Dakhla', 'MA-12', 'rejected', 'Application rejected with score 6.90 (threshold 13).');

-- Agent for region Test-Region (password: Sk5NHEc4dfX)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(40, 'ayoub.elma', '$2y$10$mrXv4fPuGx5XVsqH/NJEJOKaQhtxvzW8cRrvqRJCTTyutfbJn7oe6', 'agent', 'MA-99', 'Ayoub El Ma');

-- Institution Al Massira in region_name='Test-Region' inst_object['city']='Testville' (password: a49HSUzGbtO)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(41, 'al_massira2', '$2y$10$d/aexImZodw8nTxxTEZ4D.z3KBpoccV3kS6lZihTrAt00D1Z92Gha', 'institution', 'MA-99', 'Al Massira');

INSERT INTO documents (id, student_id, filename, type) VALUES
(110, '2007XX938256', '2007XX938256_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(111, '2007XX938256', '2007XX938256_etat_civil.pdf', 'pdf');

-- Application for student 2007XX938256 (pwd: 53fcec7b92460777)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(72, '2007XX938256', 'Meryem Fassi', 1882, 'al_massira2', 'Testville', 'MA-99', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(112, '2008XX016418', '2008XX016418_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(113, '2008XX016418', '2008XX016418_etat_civil.pdf', 'pdf');

-- Application for student 2008XX016418 (pwd: c20ae1b69d1bc939)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(73, '2008XX016418', 'Salma Bouziane', 1181, 'al_massira2', 'Testville', 'MA-99', 'submitted', '');

INSERT INTO documents (id, student_id, filename, type) VALUES
(114, '2007XX828897', '2007XX828897_proof_parent_income.pdf', 'pdf');

INSERT INTO documents (id, student_id, filename, type) VALUES
(115, '2007XX828897', '2007XX828897_etat_civil.pdf', 'pdf');

-- Application for student 2007XX828897 (pwd: c0e7b40f98e76d03)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(74, '2007XX828897', 'Khadija Aziz', 2833, 'al_massira2', 'Testville', 'MA-99', 'approved', 'Application approved with score 12.91 (threshold 12).');

-- Institution Al Fath in region_name='Test-Region' inst_object['city']='Mocktown' (password: 9R6OZpCesLc)
INSERT INTO users (id, username, password, role, region, display_name) VALUES
(42, 'al_fath4', '$2y$10$S48Fn13aASaEEjEep0tLleuvFQAtJlkHuhkTPjMAwN73QjtPzlHH.', 'institution', 'MA-99', 'Al Fath');

INSERT INTO documents (id, student_id, filename, type) VALUES
(116, '2008XX579902', '2008XX579902_etat_civil.pdf', 'pdf');

-- Application for student 2008XX579902 (pwd: 1e2389c03b54c912)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(75, '2008XX579902', 'Ismail Ait Ouarasse', 1521, 'al_fath4', 'Mocktown', 'MA-99', 'requiring_documents', 'Additional documents required from student.');

INSERT INTO documents (id, student_id, filename, type) VALUES
(117, '2007XX005447', '2007XX005447_etat_civil.pdf', 'pdf');

-- Application for student 2007XX005447 (pwd: e2b27079f4e5cafc)
INSERT INTO applications (id, student_id, fullname, parent_income, institution, city, region, status, agent_message) VALUES
(76, '2007XX005447', 'Malika Amzian', 2948, 'al_fath4', 'Mocktown', 'MA-99', 'requiring_documents', 'Additional documents required from student.');

