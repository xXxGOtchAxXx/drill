#!/bin/bash

echo "Waiting for MySQL to be ready..."
until mysqladmin ping -h mysql --silent; do
  sleep 2
done

echo "Checking for existing databases..."

if ! mysql -h mysql -u root -p"$MYSQL_ROOT_PASSWORD" -e "USE edusupport;" 2>/dev/null; then
  echo "Initializing databases..."

  mysql -h mysql -u root -p"$MYSQL_ROOT_PASSWORD" <<EOF
CREATE DATABASE edusupport;
CREATE DATABASE grades;

CREATE USER 'edusupport'@'%' IDENTIFIED BY '${EDUSUPPORT_DB_PASSWORD}';
CREATE USER 'grades'@'%' IDENTIFIED BY '${GRADES_DB_PASSWORD}';

GRANT ALL PRIVILEGES ON edusupport.* TO 'edusupport'@'%';
GRANT ALL PRIVILEGES ON grades.* TO 'grades'@'%';

FLUSH PRIVILEGES;
EOF

  echo "Importing structure and data..."

#  mysql -h mysql -u root -p"$MYSQL_ROOT_PASSWORD" edusupport < /sql/structure_edusupport.sql
#  mysql -h mysql -u root -p"$MYSQL_ROOT_PASSWORD" edusupport < /sql/data_edusupport.sql
  mysql -h mysql -u root -p"$MYSQL_ROOT_PASSWORD" edusupport < /sql/edusupport.sql

#  mysql -h mysql -u root -p"$MYSQL_ROOT_PASSWORD" grades < /sql/structure_grades.sql
#  mysql -h mysql -u root -p"$MYSQL_ROOT_PASSWORD" grades < /sql/data_grades.sql
  mysql -h mysql -u root -p"$MYSQL_ROOT_PASSWORD" grades < /sql/grades.sql
else
  echo "Databases already exist. Skipping init."
fi
